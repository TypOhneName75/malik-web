// Seed-Skript: erstellt beim ersten Start automatisch
// - den Administrator-Account
// - die Haupt- und Unterkategorien
// Ausführen mit: npm run db:seed

const { PrismaClient } = require("@prisma/client");
const bcrypt = require("bcryptjs");

const prisma = new PrismaClient();

const CATEGORY_TREE = [
  {
    name: "Digital Stuff",
    slug: "digital-stuff",
    subcategories: [
      { name: "Social Media Services", slug: "social-media-services" },
      { name: "1", slug: "1" },
      { name: "2", slug: "2" },
    ],
  },
  {
    name: "Clothes",
    slug: "clothes",
    subcategories: [
      { name: "T-Shirts", slug: "t-shirts" },
      { name: "Shorts", slug: "shorts" },
      { name: "Pullovers", slug: "pullovers" },
      { name: "Hosen", slug: "hosen" },
      { name: "Shoes", slug: "shoes" },
      { name: "Bags Woman", slug: "bags-woman" },
      { name: "Bags Men", slug: "bags-men" },
      { name: "Other", slug: "other" },
    ],
  },
];

async function main() {
  console.log("Seeding Datenbank...");

  // 1. Admin-Account erstellen (falls noch nicht vorhanden)
  const adminUsername = process.env.ADMIN_USERNAME || "admin";
  const adminPassword = process.env.ADMIN_PASSWORD || "AdminPassword";

  const existingAdmin = await prisma.user.findUnique({
    where: { username: adminUsername },
  });

  if (!existingAdmin) {
    const passwordHash = await bcrypt.hash(adminPassword, 12);
    await prisma.user.create({
      data: {
        username: adminUsername,
        passwordHash,
        role: "ADMIN",
        balanceCents: 0,
      },
    });
    console.log(`Admin-Account "${adminUsername}" erstellt.`);
  } else {
    console.log(`Admin-Account "${adminUsername}" existiert bereits.`);
  }

  // 2. Kategorien & Unterkategorien anlegen
  for (const cat of CATEGORY_TREE) {
    const category = await prisma.category.upsert({
      where: { slug: cat.slug },
      update: { name: cat.name },
      create: { name: cat.name, slug: cat.slug },
    });

    for (const sub of cat.subcategories) {
      await prisma.subcategory.upsert({
        where: { categoryId_slug: { categoryId: category.id, slug: sub.slug } },
        update: { name: sub.name },
        create: { name: sub.name, slug: sub.slug, categoryId: category.id },
      });
    }
    console.log(`Kategorie "${cat.name}" mit Unterkategorien angelegt.`);
  }

  console.log("Seeding abgeschlossen.");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
