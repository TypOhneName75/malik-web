"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { CheckCircle2, AlertTriangle } from "lucide-react";
import { formatPrice } from "@/lib/format";
import { useAuth } from "@/components/AuthProvider";

interface CartItem {
  id: string;
  quantity: number;
  product: { id: string; title: string; priceCents: number };
}

export default function CheckoutPage() {
  const { user, loading: authLoading, refresh } = useAuth();
  const router = useRouter();

  const [items, setItems] = useState<CartItem[]>([]);
  const [totalCents, setTotalCents] = useState(0);
  const [balanceCents, setBalanceCents] = useState(0);
  const [loading, setLoading] = useState(true);
  const [placing, setPlacing] = useState(false);
  const [error, setError] = useState("");
  const [confirmedOrderId, setConfirmedOrderId] = useState<string | null>(null);

  useEffect(() => {
    if (authLoading) return;
    if (!user) {
      router.push("/login?redirect=/checkout");
      return;
    }
    fetch("/api/cart")
      .then((r) => r.json())
      .then((d) => {
        setItems(d.items ?? []);
        setTotalCents(d.totalCents ?? 0);
        setBalanceCents(d.balanceCents ?? 0);
      })
      .finally(() => setLoading(false));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [authLoading, user]);

  async function placeOrder() {
    setPlacing(true);
    setError("");
    const res = await fetch("/api/checkout", { method: "POST" });
    const data = await res.json();
    setPlacing(false);
    if (!res.ok) {
      setError(data.error ?? "Checkout fehlgeschlagen");
      return;
    }
    setConfirmedOrderId(data.order.id);
    refresh();
  }

  if (authLoading || loading) {
    return <div className="mx-auto max-w-2xl px-4 py-20 text-center text-gray-500">Lädt...</div>;
  }

  if (confirmedOrderId) {
    return (
      <div className="mx-auto max-w-lg px-4 py-20 text-center">
        <CheckCircle2 className="mx-auto h-16 w-16 text-neon-green" />
        <h1 className="mt-4 font-display text-2xl font-bold text-white">
          Bestellung bestätigt!
        </h1>
        <p className="mt-2 text-gray-400">
          Deine Bestellung <span className="text-neon-blue">#{confirmedOrderId.slice(-8)}</span> wurde erfolgreich aufgegeben.
        </p>
        <div className="mt-8 flex justify-center gap-3">
          <Link href="/dashboard" className="neon-btn">Zum Dashboard</Link>
          <Link href="/shop" className="neon-btn-outline">Weiter shoppen</Link>
        </div>
      </div>
    );
  }

  if (items.length === 0) {
    return (
      <div className="mx-auto max-w-lg px-4 py-20 text-center text-gray-500">
        Dein Warenkorb ist leer.
        <div className="mt-4">
          <Link href="/shop" className="neon-btn">Zum Shop</Link>
        </div>
      </div>
    );
  }

  const insufficientBalance = balanceCents < totalCents;

  return (
    <div className="mx-auto max-w-2xl px-4 py-10 md:px-8">
      <h1 className="font-display text-3xl font-bold text-white">Kasse</h1>

      <div className="glass-card mt-8 divide-y divide-white/10">
        {items.map((item) => (
          <div key={item.id} className="flex justify-between p-4 text-sm">
            <span className="text-gray-300">
              {item.product.title} <span className="text-gray-600">× {item.quantity}</span>
            </span>
            <span className="text-gray-300">{formatPrice(item.product.priceCents * item.quantity)}</span>
          </div>
        ))}
        <div className="flex justify-between p-4 font-bold text-white">
          <span>Gesamt</span>
          <span>{formatPrice(totalCents)}</span>
        </div>
      </div>

      <div className="glass-card mt-4 flex items-center justify-between p-4">
        <span className="text-sm text-gray-400">Bezahlung via Wallet-Guthaben</span>
        <span className={insufficientBalance ? "text-red-400" : "text-neon-green"}>
          {formatPrice(balanceCents)} verfügbar
        </span>
      </div>

      {error && (
        <div className="mt-4 flex items-center gap-2 rounded-xl border border-red-500/30 bg-red-500/10 p-3 text-sm text-red-400">
          <AlertTriangle className="h-4 w-4 flex-shrink-0" /> {error}
        </div>
      )}

      {insufficientBalance ? (
        <Link href="/dashboard/wallet" className="neon-btn mt-6 w-full justify-center">
          Wallet aufladen
        </Link>
      ) : (
        <button
          onClick={placeOrder}
          disabled={placing}
          className="neon-btn mt-6 w-full justify-center"
        >
          {placing ? "Wird verarbeitet..." : "Jetzt kostenpflichtig bestellen"}
        </button>
      )}
    </div>
  );
}
