"use client";

import { useEffect, useState, useCallback } from "react";
import { useSearchParams, useRouter } from "next/navigation";
import { Search, SlidersHorizontal, X } from "lucide-react";
import ProductCard from "@/components/ProductCard";

interface Subcategory { id: string; name: string; slug: string; }
interface Category { id: string; name: string; slug: string; subcategories: Subcategory[]; }
interface Product {
  id: string; title: string; priceCents: number; images: string[]; stock: number;
  category?: { name: string; slug: string }; subcategory?: { name: string; slug: string };
}

export default function ShopPage() {
  const searchParams = useSearchParams();
  const router = useRouter();

  const [categories, setCategories] = useState<Category[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [filtersOpen, setFiltersOpen] = useState(false);

  const [q, setQ] = useState(searchParams.get("q") ?? "");
  const category = searchParams.get("category") ?? "";
  const subcategory = searchParams.get("subcategory") ?? "";
  const sort = searchParams.get("sort") ?? "newest";
  const minPrice = searchParams.get("minPrice") ?? "";
  const maxPrice = searchParams.get("maxPrice") ?? "";

  useEffect(() => {
    fetch("/api/categories").then((r) => r.json()).then((d) => setCategories(d.categories ?? []));
  }, []);

  const updateParams = useCallback(
    (updates: Record<string, string>) => {
      const params = new URLSearchParams(searchParams.toString());
      Object.entries(updates).forEach(([key, value]) => {
        if (value) params.set(key, value);
        else params.delete(key);
      });
      router.push(`/shop?${params.toString()}`);
    },
    [searchParams, router]
  );

  useEffect(() => {
    setLoading(true);
    const params = new URLSearchParams();
    if (q) params.set("q", q);
    if (category) params.set("category", category);
    if (subcategory) params.set("subcategory", subcategory);
    if (sort) params.set("sort", sort);
    if (minPrice) params.set("minPrice", String(Number(minPrice) * 100));
    if (maxPrice) params.set("maxPrice", String(Number(maxPrice) * 100));

    fetch(`/api/products?${params.toString()}`)
      .then((r) => r.json())
      .then((d) => setProducts(d.products ?? []))
      .finally(() => setLoading(false));
  }, [q, category, subcategory, sort, minPrice, maxPrice]);

  const activeCategory = categories.find((c) => c.slug === category);

  return (
    <div className="mx-auto max-w-7xl px-4 py-10 md:px-8">
      <h1 className="font-display text-3xl font-bold text-white">Shop</h1>

      {/* Suche */}
      <div className="mt-6 flex flex-col gap-3 sm:flex-row">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-500" />
          <input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && updateParams({ q })}
            placeholder="Produkte durchsuchen..."
            className="neon-input pl-10"
          />
        </div>
        <button
          onClick={() => setFiltersOpen((v) => !v)}
          className="neon-btn-outline sm:w-auto"
        >
          <SlidersHorizontal className="h-4 w-4" /> Filter
        </button>
      </div>

      {/* Kategorie-Chips */}
      <div className="mt-4 flex flex-wrap gap-2">
        <button
          onClick={() => updateParams({ category: "", subcategory: "" })}
          className={`badge cursor-pointer border ${!category ? "border-neon-blue bg-neon-blue/10 text-neon-blue" : "border-white/10 text-gray-400 hover:border-white/30"}`}
        >
          Alle
        </button>
        {categories.map((cat) => (
          <button
            key={cat.id}
            onClick={() => updateParams({ category: cat.slug, subcategory: "" })}
            className={`badge cursor-pointer border ${category === cat.slug ? "border-neon-blue bg-neon-blue/10 text-neon-blue" : "border-white/10 text-gray-400 hover:border-white/30"}`}
          >
            {cat.name}
          </button>
        ))}
      </div>

      {activeCategory && (
        <div className="mt-3 flex flex-wrap gap-2">
          {activeCategory.subcategories.map((sub) => (
            <button
              key={sub.id}
              onClick={() => updateParams({ subcategory: sub.slug })}
              className={`badge cursor-pointer border ${subcategory === sub.slug ? "border-neon-purple bg-neon-purple/10 text-neon-purple" : "border-white/10 text-gray-500 hover:border-white/30"}`}
            >
              {sub.name}
            </button>
          ))}
        </div>
      )}

      {/* Filter-Panel */}
      {filtersOpen && (
        <div className="glass-card mt-4 flex flex-wrap items-end gap-4 p-4">
          <div>
            <label className="block text-xs text-gray-500">Min. Preis (€)</label>
            <input
              type="number"
              defaultValue={minPrice}
              onBlur={(e) => updateParams({ minPrice: e.target.value })}
              className="neon-input mt-1 w-28"
            />
          </div>
          <div>
            <label className="block text-xs text-gray-500">Max. Preis (€)</label>
            <input
              type="number"
              defaultValue={maxPrice}
              onBlur={(e) => updateParams({ maxPrice: e.target.value })}
              className="neon-input mt-1 w-28"
            />
          </div>
          <div>
            <label className="block text-xs text-gray-500">Sortierung</label>
            <select
              value={sort}
              onChange={(e) => updateParams({ sort: e.target.value })}
              className="neon-input mt-1"
            >
              <option value="newest">Neueste</option>
              <option value="price_asc">Preis aufsteigend</option>
              <option value="price_desc">Preis absteigend</option>
            </select>
          </div>
          <button
            onClick={() => {
              setQ("");
              router.push("/shop");
            }}
            className="flex items-center gap-1 text-sm text-gray-500 hover:text-white"
          >
            <X className="h-4 w-4" /> Filter zurücksetzen
          </button>
        </div>
      )}

      {/* Produkte */}
      <div className="mt-8">
        {loading ? (
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
            {Array.from({ length: 8 }).map((_, i) => (
              <div key={i} className="glass-card aspect-square animate-pulse" />
            ))}
          </div>
        ) : products.length === 0 ? (
          <p className="py-20 text-center text-gray-500">
            Keine Produkte gefunden.
          </p>
        ) : (
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
            {products.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
