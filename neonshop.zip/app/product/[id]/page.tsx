"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import { ShoppingCart, Zap, PackageX, ChevronLeft } from "lucide-react";
import Link from "next/link";
import { formatPrice } from "@/lib/format";
import { useAuth } from "@/components/AuthProvider";

interface Product {
  id: string;
  title: string;
  description: string;
  priceCents: number;
  images: string[];
  stock: number;
  category: { name: string; slug: string };
  subcategory: { name: string; slug: string };
}

export default function ProductPage() {
  const params = useParams<{ id: string }>();
  const router = useRouter();
  const { user } = useAuth();

  const [product, setProduct] = useState<Product | null>(null);
  const [activeImage, setActiveImage] = useState(0);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(false);
  const [message, setMessage] = useState("");

  useEffect(() => {
    fetch(`/api/products/${params.id}`)
      .then((r) => r.json())
      .then((d) => setProduct(d.product ?? null))
      .finally(() => setLoading(false));
  }, [params.id]);

  async function addToCart() {
    if (!user) return router.push("/login");
    setActionLoading(true);
    const res = await fetch("/api/cart", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ productId: params.id, quantity: 1 }),
    });
    setActionLoading(false);
    setMessage(res.ok ? "Zum Warenkorb hinzugefügt ✓" : "Fehler beim Hinzufügen");
  }

  async function buyNow() {
    if (!user) return router.push("/login");
    setActionLoading(true);
    const addRes = await fetch("/api/cart", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ productId: params.id, quantity: 1 }),
    });
    if (addRes.ok) {
      router.push("/checkout");
    } else {
      setActionLoading(false);
      setMessage("Fehler beim Kauf");
    }
  }

  if (loading) {
    return <div className="mx-auto max-w-5xl px-4 py-20 text-center text-gray-500">Lädt...</div>;
  }
  if (!product) {
    return (
      <div className="mx-auto max-w-5xl px-4 py-20 text-center">
        <p className="text-gray-500">Produkt nicht gefunden.</p>
        <Link href="/shop" className="mt-4 inline-block text-neon-blue">Zurück zum Shop</Link>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-6xl px-4 py-10 md:px-8">
      <Link href="/shop" className="flex items-center gap-1 text-sm text-gray-500 hover:text-white">
        <ChevronLeft className="h-4 w-4" /> Zurück zum Shop
      </Link>

      <div className="mt-6 grid grid-cols-1 gap-10 md:grid-cols-2">
        {/* Bildergalerie */}
        <div>
          <div className="glass-card aspect-square overflow-hidden">
            {product.images?.[activeImage] ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img
                src={product.images[activeImage]}
                alt={product.title}
                className="h-full w-full object-cover"
              />
            ) : (
              <div className="flex h-full items-center justify-center text-gray-600">
                <PackageX className="h-16 w-16" />
              </div>
            )}
          </div>
          {product.images?.length > 1 && (
            <div className="mt-3 flex gap-2">
              {product.images.map((img, i) => (
                <button
                  key={i}
                  onClick={() => setActiveImage(i)}
                  className={`h-16 w-16 overflow-hidden rounded-lg border-2 ${
                    activeImage === i ? "border-neon-blue" : "border-white/10"
                  }`}
                >
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={img} alt="" className="h-full w-full object-cover" />
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Info */}
        <div>
          <div className="flex gap-2">
            <span className="badge border border-neon-blue/40 bg-neon-blue/10 text-neon-blue">
              {product.category.name}
            </span>
            <span className="badge border border-neon-purple/40 bg-neon-purple/10 text-neon-purple">
              {product.subcategory.name}
            </span>
          </div>

          <h1 className="mt-4 font-display text-3xl font-bold text-white">{product.title}</h1>
          <p className="mt-4 whitespace-pre-line text-gray-400">{product.description}</p>

          <div className="mt-6 flex items-center gap-4">
            <span className="font-display text-3xl font-black text-neon-green">
              {formatPrice(product.priceCents)}
            </span>
            {product.stock > 0 ? (
              <span className="badge bg-neon-green/10 text-neon-green">
                {product.stock} auf Lager
              </span>
            ) : (
              <span className="badge bg-red-500/10 text-red-400">Ausverkauft</span>
            )}
          </div>

          <div className="mt-8 flex flex-col gap-3 sm:flex-row">
            <button
              onClick={addToCart}
              disabled={actionLoading || product.stock === 0}
              className="neon-btn-outline flex-1"
            >
              <ShoppingCart className="h-4 w-4" /> In den Warenkorb
            </button>
            <button
              onClick={buyNow}
              disabled={actionLoading || product.stock === 0}
              className="neon-btn flex-1"
            >
              <Zap className="h-4 w-4" /> Jetzt kaufen
            </button>
          </div>
          {message && <p className="mt-3 text-sm text-neon-green">{message}</p>}
        </div>
      </div>
    </div>
  );
}
