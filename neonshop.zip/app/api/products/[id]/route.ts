import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

export async function GET(
  _req: NextRequest,
  { params }: { params: { id: string } }
) {
  const product = await prisma.product.findUnique({
    where: { id: params.id },
    include: { category: true, subcategory: true },
  });

  if (!product || !product.isActive) {
    return NextResponse.json({ error: "Produkt nicht gefunden" }, { status: 404 });
  }

  return NextResponse.json({ product });
}
