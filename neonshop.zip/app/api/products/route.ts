import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";

// GET /api/products?q=suche&category=slug&subcategory=slug&minPrice=0&maxPrice=1000&sort=price_asc
export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const q = searchParams.get("q")?.trim();
  const category = searchParams.get("category");
  const subcategory = searchParams.get("subcategory");
  const minPrice = searchParams.get("minPrice");
  const maxPrice = searchParams.get("maxPrice");
  const sort = searchParams.get("sort") ?? "newest";

  const where: any = { isActive: true };

  if (q) {
    where.OR = [
      { title: { contains: q, mode: "insensitive" } },
      { description: { contains: q, mode: "insensitive" } },
    ];
  }
  if (category) where.category = { slug: category };
  if (subcategory) where.subcategory = { slug: subcategory };
  if (minPrice || maxPrice) {
    where.priceCents = {};
    if (minPrice) where.priceCents.gte = Number(minPrice);
    if (maxPrice) where.priceCents.lte = Number(maxPrice);
  }

  const orderBy: any =
    sort === "price_asc"
      ? { priceCents: "asc" }
      : sort === "price_desc"
      ? { priceCents: "desc" }
      : { createdAt: "desc" };

  const products = await prisma.product.findMany({
    where,
    orderBy,
    include: { category: true, subcategory: true },
    take: 60,
  });

  return NextResponse.json({ products });
}
