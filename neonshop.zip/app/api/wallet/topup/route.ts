import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";
import { z } from "zod";

const topupSchema = z.object({
  amountCents: z.number().int().positive().max(500_000), // max. 5.000 Euro pro Aufladung
});

// Vereinfachte Aufladung. In Produktion: Stripe Checkout Session erstellen,
// Guthaben erst nach bestätigtem Webhook-Event ("checkout.session.completed")
// gutschreiben - NICHT direkt hier, sonst können Nutzer sich ungeprüft
// Guthaben gutschreiben.
export async function POST(req: NextRequest) {
  const user = await getCurrentUser(req);
  if (!user) return NextResponse.json({ error: "Nicht eingeloggt" }, { status: 401 });

  const body = await req.json().catch(() => null);
  const parsed = topupSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: "Ungültiger Betrag" }, { status: 400 });
  }

  if (!process.env.STRIPE_SECRET_KEY) {
    return NextResponse.json(
      {
        error:
          "Zahlungsanbieter nicht konfiguriert. STRIPE_SECRET_KEY in .env setzen.",
      },
      { status: 503 }
    );
  }

  // TODO: Stripe Checkout Session erstellen und checkoutUrl zurückgeben.
  // Die tatsächliche Gutschrift erfolgt im Stripe-Webhook-Handler
  // (app/api/wallet/webhook/route.ts), nicht in dieser Route.

  return NextResponse.json(
    { error: "Stripe-Integration noch nicht abgeschlossen" },
    { status: 501 }
  );
}
