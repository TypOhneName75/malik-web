import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAdmin } from "@/lib/auth";

export async function GET(req: NextRequest) {
  try {
    await requireAdmin(req);
  } catch {
    return NextResponse.json({ error: "Kein Zugriff" }, { status: 403 });
  }

  const [userCount, productCount, orderCount, openTickets, revenueAgg] =
    await Promise.all([
      prisma.user.count(),
      prisma.product.count(),
      prisma.order.count({ where: { status: "PAID" } }),
      prisma.ticket.count({ where: { status: { not: "CLOSED" } } }),
      prisma.order.aggregate({
        where: { status: "PAID" },
        _sum: { totalCents: true },
      }),
    ]);

  return NextResponse.json({
    userCount,
    productCount,
    orderCount,
    openTickets,
    revenueCents: revenueAgg._sum.totalCents ?? 0,
  });
}
