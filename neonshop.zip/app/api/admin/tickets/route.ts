import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAdmin } from "@/lib/auth";

export async function GET(req: NextRequest) {
  try {
    await requireAdmin(req);
  } catch {
    return NextResponse.json({ error: "Kein Zugriff" }, { status: 403 });
  }

  const tickets = await prisma.ticket.findMany({
    include: { user: { select: { username: true } } },
    orderBy: { updatedAt: "desc" },
  });

  return NextResponse.json({ tickets });
}
