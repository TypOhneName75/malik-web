import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAdmin } from "@/lib/auth";
import { z } from "zod";

const updateSchema = z.object({
  isBanned: z.boolean().optional(),
  // Guthaben-Delta in Cent, kann positiv (Gutschrift) oder negativ (Abzug) sein
  balanceAdjustmentCents: z.number().int().optional(),
  adjustmentNote: z.string().max(300).optional(),
});

export async function PATCH(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  let admin;
  try {
    admin = await requireAdmin(req);
  } catch {
    return NextResponse.json({ error: "Kein Zugriff" }, { status: 403 });
  }

  const body = await req.json().catch(() => null);
  const parsed = updateSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: "Ungültige Eingabe" }, { status: 400 });
  }

  const { isBanned, balanceAdjustmentCents, adjustmentNote } = parsed.data;

  const targetUser = await prisma.user.findUnique({ where: { id: params.id } });
  if (!targetUser) {
    return NextResponse.json({ error: "Benutzer nicht gefunden" }, { status: 404 });
  }

  // Admins können sich nicht selbst sperren
  if (isBanned && targetUser.id === admin.id) {
    return NextResponse.json(
      { error: "Du kannst dich nicht selbst sperren" },
      { status: 400 }
    );
  }

  const result = await prisma.$transaction(async (tx) => {
    const updateData: any = {};
    if (typeof isBanned === "boolean") updateData.isBanned = isBanned;

    if (balanceAdjustmentCents) {
      updateData.balanceCents = { increment: balanceAdjustmentCents };
      await tx.walletTransaction.create({
        data: {
          userId: targetUser.id,
          amountCents: balanceAdjustmentCents,
          type: "ADMIN_ADJUSTMENT",
          note: adjustmentNote || `Manuelle Anpassung durch Admin ${admin.username}`,
        },
      });
    }

    return tx.user.update({ where: { id: targetUser.id }, data: updateData });
  });

  return NextResponse.json({
    user: {
      id: result.id,
      username: result.username,
      role: result.role,
      balanceCents: result.balanceCents,
      isBanned: result.isBanned,
    },
  });
}
