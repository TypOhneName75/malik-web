import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireAdmin } from "@/lib/auth";
import { z } from "zod";

const subcategorySchema = z.object({
  name: z.string().min(1).max(100),
  slug: z
    .string()
    .min(1)
    .max(100)
    .regex(/^[a-z0-9-]+$/, "Nur Kleinbuchstaben, Zahlen und - erlaubt"),
  categoryId: z.string().min(1),
});

export async function POST(req: NextRequest) {
  try {
    await requireAdmin(req);
  } catch {
    return NextResponse.json({ error: "Kein Zugriff" }, { status: 403 });
  }

  const body = await req.json().catch(() => null);
  const parsed = subcategorySchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: parsed.error.issues[0]?.message ?? "Ungültige Eingabe" },
      { status: 400 }
    );
  }

  const subcategory = await prisma.subcategory.create({ data: parsed.data });
  return NextResponse.json({ subcategory });
}
