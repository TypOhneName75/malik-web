import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";
import { ticketCreateSchema } from "@/lib/validation";

export async function GET(req: NextRequest) {
  const user = await getCurrentUser(req);
  if (!user) return NextResponse.json({ error: "Nicht eingeloggt" }, { status: 401 });

  const tickets = await prisma.ticket.findMany({
    where: { userId: user.id },
    orderBy: { updatedAt: "desc" },
  });

  return NextResponse.json({ tickets });
}

export async function POST(req: NextRequest) {
  const user = await getCurrentUser(req);
  if (!user) return NextResponse.json({ error: "Nicht eingeloggt" }, { status: 401 });

  const body = await req.json().catch(() => null);
  const parsed = ticketCreateSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: parsed.error.issues[0]?.message ?? "Ungültige Eingabe" },
      { status: 400 }
    );
  }

  const { subject, category, message } = parsed.data;

  const ticket = await prisma.ticket.create({
    data: {
      userId: user.id,
      subject,
      category,
      status: "OPEN",
      replies: {
        create: { userId: user.id, author: "USER", message },
      },
    },
    include: { replies: true },
  });

  return NextResponse.json({ ticket });
}
