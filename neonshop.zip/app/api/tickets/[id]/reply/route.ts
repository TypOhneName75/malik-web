import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";
import { ticketReplySchema } from "@/lib/validation";

export async function POST(
  req: NextRequest,
  { params }: { params: { id: string } }
) {
  const user = await getCurrentUser(req);
  if (!user) return NextResponse.json({ error: "Nicht eingeloggt" }, { status: 401 });

  const ticket = await prisma.ticket.findUnique({ where: { id: params.id } });
  if (!ticket) return NextResponse.json({ error: "Nicht gefunden" }, { status: 404 });
  if (ticket.userId !== user.id && user.role !== "ADMIN") {
    return NextResponse.json({ error: "Kein Zugriff" }, { status: 403 });
  }
  if (ticket.status === "CLOSED") {
    return NextResponse.json(
      { error: "Ticket ist geschlossen" },
      { status: 400 }
    );
  }

  const body = await req.json().catch(() => null);
  const parsed = ticketReplySchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: "Ungültige Nachricht" }, { status: 400 });
  }

  const reply = await prisma.ticketReply.create({
    data: {
      ticketId: ticket.id,
      userId: user.id,
      author: user.role === "ADMIN" ? "ADMIN" : "USER",
      message: parsed.data.message,
    },
  });

  await prisma.ticket.update({
    where: { id: ticket.id },
    data: {
      status: user.role === "ADMIN" ? "IN_PROGRESS" : ticket.status,
      updatedAt: new Date(),
    },
  });

  return NextResponse.json({ reply });
}
