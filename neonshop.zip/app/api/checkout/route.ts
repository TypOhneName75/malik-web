import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { getCurrentUser } from "@/lib/auth";

// POST /api/checkout - kauft den gesamten aktuellen Warenkorb
export async function POST(req: NextRequest) {
  const user = await getCurrentUser(req);
  if (!user) return NextResponse.json({ error: "Nicht eingeloggt" }, { status: 401 });

  try {
    const order = await prisma.$transaction(async (tx) => {
      const cartItems = await tx.cartItem.findMany({
        where: { userId: user.id },
        include: { product: true },
      });

      if (cartItems.length === 0) {
        throw new Error("EMPTY_CART");
      }

      // Stock & Verfügbarkeit erneut prüfen (Race-Condition-Schutz)
      for (const item of cartItems) {
        if (!item.product.isActive || item.product.stock < item.quantity) {
          throw new Error(`OUT_OF_STOCK:${item.product.title}`);
        }
      }

      const totalCents = cartItems.reduce(
        (sum, item) => sum + item.product.priceCents * item.quantity,
        0
      );

      // Aktuellen Kontostand innerhalb der Transaktion frisch lesen
      const freshUser = await tx.user.findUniqueOrThrow({ where: { id: user.id } });
      if (freshUser.balanceCents < totalCents) {
        throw new Error("INSUFFICIENT_BALANCE");
      }

      // Bestellung anlegen
      const newOrder = await tx.order.create({
        data: {
          userId: user.id,
          totalCents,
          status: "PAID",
          items: {
            create: cartItems.map((item) => ({
              productId: item.productId,
              title: item.product.title,
              priceCents: item.product.priceCents,
              quantity: item.quantity,
            })),
          },
        },
        include: { items: true },
      });

      // Lagerbestand reduzieren
      for (const item of cartItems) {
        await tx.product.update({
          where: { id: item.productId },
          data: { stock: { decrement: item.quantity } },
        });
      }

      // Guthaben abziehen + Transaktion protokollieren
      await tx.user.update({
        where: { id: user.id },
        data: { balanceCents: { decrement: totalCents } },
      });
      await tx.walletTransaction.create({
        data: {
          userId: user.id,
          amountCents: -totalCents,
          type: "PURCHASE",
          note: `Bestellung ${newOrder.id}`,
        },
      });

      // Warenkorb leeren
      await tx.cartItem.deleteMany({ where: { userId: user.id } });

      return newOrder;
    });

    return NextResponse.json({ order });
  } catch (err: any) {
    const message = err?.message ?? "Unbekannter Fehler";
    if (message === "EMPTY_CART") {
      return NextResponse.json({ error: "Warenkorb ist leer" }, { status: 400 });
    }
    if (message === "INSUFFICIENT_BALANCE") {
      return NextResponse.json(
        { error: "Guthaben reicht nicht aus. Bitte Wallet aufladen." },
        { status: 400 }
      );
    }
    if (message.startsWith("OUT_OF_STOCK")) {
      return NextResponse.json(
        { error: `Nicht mehr verfügbar: ${message.split(":")[1]}` },
        { status: 400 }
      );
    }
    return NextResponse.json({ error: "Checkout fehlgeschlagen" }, { status: 500 });
  }
}
