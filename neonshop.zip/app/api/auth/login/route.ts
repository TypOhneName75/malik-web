import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { verifyPassword, signSession, SESSION_COOKIE_NAME } from "@/lib/auth";
import { loginSchema } from "@/lib/validation";
import { checkRateLimit } from "@/lib/rateLimit";

export async function POST(req: NextRequest) {
  const ip = req.headers.get("x-forwarded-for") ?? "unknown";
  const body = await req.json().catch(() => null);
  const parsed = loginSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: parsed.error.issues[0]?.message ?? "Ungültige Eingabe" },
      { status: 400 }
    );
  }

  const { username, password } = parsed.data;

  // Rate Limit pro IP UND pro Username, um Brute-Force auf einzelne Accounts
  // sowie verteilte Angriffe zu verhindern.
  const rlIp = checkRateLimit(`login-ip:${ip}`);
  const rlUser = checkRateLimit(`login-user:${username}`);
  if (!rlIp.allowed || !rlUser.allowed) {
    return NextResponse.json(
      { error: "Zu viele Login-Versuche. Bitte später erneut versuchen." },
      { status: 429 }
    );
  }

  const user = await prisma.user.findUnique({ where: { username } });

  // Generische Fehlermeldung, um nicht zu verraten ob der Username existiert
  const genericError = () =>
    NextResponse.json({ error: "Username oder Passwort falsch" }, { status: 401 });

  if (!user) return genericError();
  if (user.isBanned) {
    return NextResponse.json(
      { error: "Dieser Account wurde gesperrt." },
      { status: 403 }
    );
  }

  const valid = await verifyPassword(password, user.passwordHash);
  if (!valid) return genericError();

  const token = signSession({
    userId: user.id,
    username: user.username,
    role: user.role,
  });

  const res = NextResponse.json({
    user: { id: user.id, username: user.username, role: user.role },
  });

  res.cookies.set(SESSION_COOKIE_NAME, token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "strict",
    path: "/",
    maxAge: 60 * 60 * 24 * 7,
  });

  return res;
}
