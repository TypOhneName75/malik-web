"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { Plus, X } from "lucide-react";
import { useAuth } from "@/components/AuthProvider";

interface Ticket {
  id: string;
  subject: string;
  category: string;
  status: string;
  updatedAt: string;
}

const statusColors: Record<string, string> = {
  OPEN: "bg-neon-blue/10 text-neon-blue",
  IN_PROGRESS: "bg-yellow-500/10 text-yellow-400",
  CLOSED: "bg-gray-500/10 text-gray-400",
};
const statusLabels: Record<string, string> = {
  OPEN: "Offen",
  IN_PROGRESS: "In Bearbeitung",
  CLOSED: "Geschlossen",
};

const categories = ["Bestellung", "Zahlung / Wallet", "Account", "Sonstiges"];

export default function TicketsPage() {
  const { user, loading: authLoading } = useAuth();
  const router = useRouter();
  const [tickets, setTickets] = useState<Ticket[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [subject, setSubject] = useState("");
  const [category, setCategory] = useState(categories[0]);
  const [message, setMessage] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState("");

  async function load() {
    const res = await fetch("/api/tickets");
    if (res.ok) {
      const d = await res.json();
      setTickets(d.tickets ?? []);
    }
  }

  useEffect(() => {
    if (authLoading) return;
    if (!user) {
      router.push("/login?redirect=/dashboard/tickets");
      return;
    }
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [authLoading, user]);

  async function submitTicket(e: React.FormEvent) {
    e.preventDefault();
    setSubmitting(true);
    setError("");
    const res = await fetch("/api/tickets", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ subject, category, message }),
    });
    const data = await res.json();
    setSubmitting(false);
    if (!res.ok) {
      setError(data.error ?? "Fehler beim Erstellen");
      return;
    }
    setShowForm(false);
    setSubject("");
    setMessage("");
    router.push(`/dashboard/tickets/${data.ticket.id}`);
  }

  if (authLoading || !user) {
    return <div className="mx-auto max-w-3xl px-4 py-20 text-center text-gray-500">Lädt...</div>;
  }

  return (
    <div className="mx-auto max-w-3xl px-4 py-10 md:px-8">
      <div className="flex items-center justify-between">
        <h1 className="font-display text-3xl font-bold text-white">Support-Tickets</h1>
        <button onClick={() => setShowForm((v) => !v)} className="neon-btn">
          {showForm ? <X className="h-4 w-4" /> : <Plus className="h-4 w-4" />}
          {showForm ? "Abbrechen" : "Neues Ticket"}
        </button>
      </div>

      {showForm && (
        <form onSubmit={submitTicket} className="glass-card mt-6 space-y-4 p-6">
          <input
            value={subject}
            onChange={(e) => setSubject(e.target.value)}
            placeholder="Betreff"
            required
            className="neon-input"
          />
          <select value={category} onChange={(e) => setCategory(e.target.value)} className="neon-input">
            {categories.map((c) => (
              <option key={c} value={c}>{c}</option>
            ))}
          </select>
          <textarea
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            placeholder="Beschreibe dein Anliegen..."
            required
            rows={4}
            className="neon-input"
          />
          {error && <p className="text-sm text-red-400">{error}</p>}
          <button type="submit" disabled={submitting} className="neon-btn w-full justify-center">
            {submitting ? "Wird gesendet..." : "Ticket erstellen"}
          </button>
        </form>
      )}

      <div className="mt-6 space-y-3">
        {tickets.length === 0 && (
          <p className="text-sm text-gray-500">Du hast noch keine Support-Tickets erstellt.</p>
        )}
        {tickets.map((t) => (
          <Link key={t.id} href={`/dashboard/tickets/${t.id}`} className="glass-card flex items-center justify-between p-4 hover:border-neon-blue/40">
            <div>
              <p className="font-semibold text-gray-100">{t.subject}</p>
              <p className="text-xs text-gray-500">{t.category}</p>
            </div>
            <span className={`badge ${statusColors[t.status]}`}>{statusLabels[t.status]}</span>
          </Link>
        ))}
      </div>
    </div>
  );
}
