"use client";

import { useEffect, useState, useRef } from "react";
import { useParams, useRouter } from "next/navigation";
import { Send, ChevronLeft } from "lucide-react";
import Link from "next/link";
import { useAuth } from "@/components/AuthProvider";

interface Reply {
  id: string;
  author: "USER" | "ADMIN";
  message: string;
  createdAt: string;
}
interface TicketDetail {
  id: string;
  subject: string;
  category: string;
  status: string;
  replies: Reply[];
}

const statusLabels: Record<string, string> = {
  OPEN: "Offen",
  IN_PROGRESS: "In Bearbeitung",
  CLOSED: "Geschlossen",
};

export default function TicketDetailPage() {
  const params = useParams<{ id: string }>();
  const { user, loading: authLoading } = useAuth();
  const router = useRouter();
  const [ticket, setTicket] = useState<TicketDetail | null>(null);
  const [message, setMessage] = useState("");
  const [sending, setSending] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  async function load() {
    const res = await fetch(`/api/tickets/${params.id}`);
    if (res.ok) {
      const d = await res.json();
      setTicket(d.ticket);
    }
  }

  useEffect(() => {
    if (authLoading) return;
    if (!user) {
      router.push(`/login?redirect=/dashboard/tickets/${params.id}`);
      return;
    }
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [authLoading, user, params.id]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [ticket?.replies?.length]);

  async function sendReply(e: React.FormEvent) {
    e.preventDefault();
    if (!message.trim()) return;
    setSending(true);
    await fetch(`/api/tickets/${params.id}/reply`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message }),
    });
    setMessage("");
    setSending(false);
    load();
  }

  if (authLoading || !ticket) {
    return <div className="mx-auto max-w-3xl px-4 py-20 text-center text-gray-500">Lädt...</div>;
  }

  const isClosed = ticket.status === "CLOSED";

  return (
    <div className="mx-auto max-w-3xl px-4 py-10 md:px-8">
      <Link href="/dashboard/tickets" className="flex items-center gap-1 text-sm text-gray-500 hover:text-white">
        <ChevronLeft className="h-4 w-4" /> Zurück zu Tickets
      </Link>

      <div className="mt-4 flex items-center justify-between">
        <h1 className="font-display text-2xl font-bold text-white">{ticket.subject}</h1>
        <span className="badge bg-neon-blue/10 text-neon-blue">{statusLabels[ticket.status]}</span>
      </div>
      <p className="text-sm text-gray-500">{ticket.category}</p>

      <div className="glass-card mt-6 flex max-h-[50vh] flex-col gap-3 overflow-y-auto p-4">
        {ticket.replies.map((r) => (
          <div
            key={r.id}
            className={`max-w-[80%] rounded-2xl px-4 py-2.5 text-sm ${
              r.author === "ADMIN"
                ? "self-start bg-neon-purple/10 text-gray-200"
                : "self-end bg-neon-blue/10 text-gray-200"
            }`}
          >
            <p className="mb-1 text-xs font-semibold text-gray-500">
              {r.author === "ADMIN" ? "Support-Team" : "Du"}
            </p>
            {r.message}
          </div>
        ))}
        <div ref={bottomRef} />
      </div>

      {isClosed ? (
        <p className="mt-4 text-center text-sm text-gray-500">
          Dieses Ticket wurde geschlossen.
        </p>
      ) : (
        <form onSubmit={sendReply} className="mt-4 flex gap-2">
          <input
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            placeholder="Nachricht schreiben..."
            className="neon-input flex-1"
          />
          <button type="submit" disabled={sending} className="neon-btn">
            <Send className="h-4 w-4" />
          </button>
        </form>
      )}
    </div>
  );
}
