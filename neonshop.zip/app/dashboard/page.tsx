"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { Wallet, LifeBuoy, Package, Settings, User as UserIcon } from "lucide-react";
import { formatPrice } from "@/lib/format";
import { useAuth } from "@/components/AuthProvider";

interface Order {
  id: string;
  totalCents: number;
  status: string;
  createdAt: string;
  items: { title: string; quantity: number }[];
}
interface Ticket {
  id: string;
  subject: string;
  status: string;
  updatedAt: string;
}

const statusLabels: Record<string, string> = {
  PENDING: "Ausstehend",
  PAID: "Bezahlt",
  CANCELLED: "Storniert",
  REFUNDED: "Erstattet",
  OPEN: "Offen",
  IN_PROGRESS: "In Bearbeitung",
  CLOSED: "Geschlossen",
};

export default function DashboardPage() {
  const { user, loading: authLoading } = useAuth();
  const router = useRouter();
  const [orders, setOrders] = useState<Order[]>([]);
  const [tickets, setTickets] = useState<Ticket[]>([]);

  useEffect(() => {
    if (authLoading) return;
    if (!user) {
      router.push("/login?redirect=/dashboard");
      return;
    }
    fetch("/api/orders").then((r) => r.json()).then((d) => setOrders((d.orders ?? []).slice(0, 5)));
    fetch("/api/tickets").then((r) => r.json()).then((d) =>
      setTickets((d.tickets ?? []).filter((t: Ticket) => t.status !== "CLOSED").slice(0, 5))
    );
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [authLoading, user]);

  if (authLoading || !user) {
    return <div className="mx-auto max-w-5xl px-4 py-20 text-center text-gray-500">Lädt...</div>;
  }

  return (
    <div className="mx-auto max-w-5xl px-4 py-10 md:px-8">
      <h1 className="font-display text-3xl font-bold text-white">
        Hey, {user.username} 👋
      </h1>

      <div className="mt-6 grid grid-cols-1 gap-4 sm:grid-cols-3">
        <Link href="/dashboard/wallet" className="glass-card p-5 transition-all hover:border-neon-green/40 hover:shadow-neon-green">
          <Wallet className="h-5 w-5 text-neon-green" />
          <p className="mt-2 text-xs text-gray-500">Guthaben</p>
          <p className="font-display text-xl font-bold text-white">{formatPrice(user.balanceCents)}</p>
        </Link>
        <Link href="/dashboard/tickets" className="glass-card p-5 transition-all hover:border-neon-blue/40 hover:shadow-neon-blue">
          <LifeBuoy className="h-5 w-5 text-neon-blue" />
          <p className="mt-2 text-xs text-gray-500">Offene Tickets</p>
          <p className="font-display text-xl font-bold text-white">{tickets.length}</p>
        </Link>
        <Link href="/dashboard/profile" className="glass-card p-5 transition-all hover:border-neon-purple/40 hover:shadow-neon-purple">
          <Settings className="h-5 w-5 text-neon-purple" />
          <p className="mt-2 text-xs text-gray-500">Konto</p>
          <p className="font-display text-xl font-bold text-white">Einstellungen</p>
        </Link>
      </div>

      <div className="mt-10 grid grid-cols-1 gap-8 md:grid-cols-2">
        <div>
          <div className="flex items-center justify-between">
            <h2 className="font-display text-lg font-bold text-white flex items-center gap-2">
              <Package className="h-4 w-4 text-neon-blue" /> Letzte Bestellungen
            </h2>
          </div>
          <div className="mt-3 space-y-3">
            {orders.length === 0 && <p className="text-sm text-gray-500">Noch keine Bestellungen.</p>}
            {orders.map((o) => (
              <div key={o.id} className="glass-card p-4">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-300">#{o.id.slice(-8)}</span>
                  <span className="badge bg-neon-green/10 text-neon-green">{statusLabels[o.status] ?? o.status}</span>
                </div>
                <p className="mt-1 text-xs text-gray-500">
                  {o.items.map((i) => `${i.title} ×${i.quantity}`).join(", ")}
                </p>
                <p className="mt-1 text-sm font-semibold text-white">{formatPrice(o.totalCents)}</p>
              </div>
            ))}
          </div>
        </div>

        <div>
          <h2 className="font-display text-lg font-bold text-white flex items-center gap-2">
            <UserIcon className="h-4 w-4 text-neon-purple" /> Offene Support-Tickets
          </h2>
          <div className="mt-3 space-y-3">
            {tickets.length === 0 && <p className="text-sm text-gray-500">Keine offenen Tickets.</p>}
            {tickets.map((t) => (
              <Link key={t.id} href={`/dashboard/tickets/${t.id}`} className="glass-card block p-4 hover:border-neon-blue/40">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-300">{t.subject}</span>
                  <span className="badge bg-neon-blue/10 text-neon-blue">{statusLabels[t.status] ?? t.status}</span>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
