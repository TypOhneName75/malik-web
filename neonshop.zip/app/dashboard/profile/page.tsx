"use client";

import { useEffect } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/components/AuthProvider";
import Link from "next/link";
import { Settings, Lock } from "lucide-react";

export default function ProfilePage() {
  const { user, loading } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (loading) return;
    if (!user) router.push("/login?redirect=/dashboard/profile");
  }, [loading, user, router]);

  if (loading || !user) {
    return <div className="mx-auto max-w-2xl px-4 py-20 text-center text-gray-500">Lädt...</div>;
  }

  return (
    <div className="mx-auto max-w-2xl px-4 py-10 md:px-8">
      <h1 className="font-display text-3xl font-bold text-white">Profil</h1>

      <div className="glass-card mt-6 p-6">
        <p className="text-sm text-gray-500">Username</p>
        <p className="mt-1 font-semibold text-white">{user.username}</p>
        <p className="mt-4 text-sm text-gray-500">Rolle</p>
        <p className="mt-1 font-semibold text-white">
          {user.role === "ADMIN" ? "Administrator" : "Benutzer"}
        </p>
      </div>

      <Link href="/dashboard/settings" className="glass-card mt-4 flex items-center gap-3 p-4 hover:border-neon-blue/40">
        <Lock className="h-5 w-5 text-neon-blue" />
        <div>
          <p className="text-sm font-semibold text-white">Passwort ändern</p>
          <p className="text-xs text-gray-500">Aktualisiere dein Passwort</p>
        </div>
      </Link>
    </div>
  );
}
