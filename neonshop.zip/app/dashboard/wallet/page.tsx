"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import { Wallet, ArrowUpCircle, ArrowDownCircle } from "lucide-react";
import { formatPrice } from "@/lib/format";
import { useAuth } from "@/components/AuthProvider";

interface Transaction {
  id: string;
  amountCents: number;
  type: string;
  note: string | null;
  createdAt: string;
}

const typeLabels: Record<string, string> = {
  TOPUP: "Aufladung",
  PURCHASE: "Kauf",
  REFUND: "Erstattung",
  ADMIN_ADJUSTMENT: "Anpassung durch Admin",
};

const topupOptions = [1000, 2500, 5000, 10000]; // in Cent

export default function WalletPage() {
  const { user, loading: authLoading } = useAuth();
  const router = useRouter();
  const [balanceCents, setBalanceCents] = useState(0);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [topupMessage, setTopupMessage] = useState("");

  async function load() {
    const res = await fetch("/api/wallet");
    if (res.ok) {
      const d = await res.json();
      setBalanceCents(d.balanceCents);
      setTransactions(d.transactions ?? []);
    }
  }

  useEffect(() => {
    if (authLoading) return;
    if (!user) {
      router.push("/login?redirect=/dashboard/wallet");
      return;
    }
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [authLoading, user]);

  async function handleTopup(amountCents: number) {
    setTopupMessage("");
    const res = await fetch("/api/wallet/topup", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ amountCents }),
    });
    const data = await res.json();
    if (!res.ok) {
      setTopupMessage(data.error ?? "Aufladung derzeit nicht möglich.");
    }
  }

  if (authLoading || !user) {
    return <div className="mx-auto max-w-3xl px-4 py-20 text-center text-gray-500">Lädt...</div>;
  }

  return (
    <div className="mx-auto max-w-3xl px-4 py-10 md:px-8">
      <h1 className="font-display text-3xl font-bold text-white">Wallet</h1>

      <div className="glass-card mt-6 flex items-center justify-between p-6">
        <div>
          <p className="text-sm text-gray-500">Aktuelles Guthaben</p>
          <p className="mt-1 font-display text-3xl font-black text-neon-green">
            {formatPrice(balanceCents)}
          </p>
        </div>
        <Wallet className="h-10 w-10 text-neon-green/60" />
      </div>

      <div className="glass-card mt-6 p-6">
        <h2 className="font-display font-bold text-white">Guthaben aufladen</h2>
        <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
          {topupOptions.map((amount) => (
            <button
              key={amount}
              onClick={() => handleTopup(amount)}
              className="neon-btn-outline"
            >
              {formatPrice(amount)}
            </button>
          ))}
        </div>
        {topupMessage && <p className="mt-3 text-sm text-yellow-400">{topupMessage}</p>}
        <p className="mt-3 text-xs text-gray-600">
          Zahlungsabwicklung über Stripe/PayPal. Muss vom Betreiber mit gültigen API-Keys konfiguriert werden.
        </p>
      </div>

      <div className="mt-8">
        <h2 className="font-display font-bold text-white">Transaktionsverlauf</h2>
        <div className="mt-3 space-y-2">
          {transactions.length === 0 && (
            <p className="text-sm text-gray-500">Noch keine Transaktionen.</p>
          )}
          {transactions.map((tx) => (
            <div key={tx.id} className="glass-card flex items-center justify-between p-4">
              <div className="flex items-center gap-3">
                {tx.amountCents >= 0 ? (
                  <ArrowUpCircle className="h-5 w-5 text-neon-green" />
                ) : (
                  <ArrowDownCircle className="h-5 w-5 text-red-400" />
                )}
                <div>
                  <p className="text-sm text-gray-200">{typeLabels[tx.type] ?? tx.type}</p>
                  {tx.note && <p className="text-xs text-gray-500">{tx.note}</p>}
                </div>
              </div>
              <span className={tx.amountCents >= 0 ? "text-neon-green" : "text-red-400"}>
                {tx.amountCents >= 0 ? "+" : ""}
                {formatPrice(tx.amountCents)}
              </span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
