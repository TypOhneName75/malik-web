"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import { Zap, Lock, User as UserIcon } from "lucide-react";
import { useAuth } from "@/components/AuthProvider";

export default function RegisterPage() {
  const router = useRouter();
  const { refresh } = useAuth();

  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");

    if (password !== confirmPassword) {
      setError("Passwörter stimmen nicht überein");
      return;
    }

    setLoading(true);
    const res = await fetch("/api/auth/register", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username, password }),
    });
    const data = await res.json();
    setLoading(false);

    if (!res.ok) {
      setError(data.error ?? "Registrierung fehlgeschlagen");
      return;
    }

    await refresh();
    router.push("/dashboard");
  }

  return (
    <div className="mx-auto flex min-h-[80vh] max-w-md items-center px-4">
      <div className="glass-card w-full p-8">
        <div className="flex justify-center">
          <Zap className="h-10 w-10 text-neon-purple drop-shadow-[0_0_8px_rgba(184,41,255,0.8)]" />
        </div>
        <h1 className="mt-4 text-center font-display text-2xl font-bold text-white">
          Account erstellen
        </h1>
        <p className="mt-1 text-center text-sm text-gray-500">
          Werde Teil der NeonShop-Community
        </p>

        <form onSubmit={handleSubmit} className="mt-6 space-y-4">
          <div className="relative">
            <UserIcon className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-500" />
            <input
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="Username"
              required
              className="neon-input pl-10"
            />
          </div>
          <div className="relative">
            <Lock className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-500" />
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Passwort (min. 8 Zeichen)"
              required
              className="neon-input pl-10"
            />
          </div>
          <div className="relative">
            <Lock className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-500" />
            <input
              type="password"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              placeholder="Passwort bestätigen"
              required
              className="neon-input pl-10"
            />
          </div>

          {error && <p className="text-sm text-red-400">{error}</p>}

          <button type="submit" disabled={loading} className="neon-btn w-full justify-center">
            {loading ? "Wird erstellt..." : "Registrieren"}
          </button>
        </form>

        <p className="mt-6 text-center text-sm text-gray-500">
          Bereits registriert?{" "}
          <Link href="/login" className="text-neon-purple hover:underline">
            Jetzt einloggen
          </Link>
        </p>
      </div>
    </div>
  );
}
