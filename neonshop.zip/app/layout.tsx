import type { Metadata } from "next";
import "./globals.css";
import { AuthProvider } from "@/components/AuthProvider";
import Navbar from "@/components/Navbar";

export const metadata: Metadata = {
  title: "NeonShop — Digital Goods & Streetwear",
  description:
    "Moderner Online-Shop im Gamer-Style für digitale Produkte und Clothing. Dark Mode, Neon-Design, sicherer Checkout.",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="de" className="dark">
      <body>
        <AuthProvider>
          <Navbar />
          <main className="min-h-[calc(100vh-64px)]">{children}</main>
          <footer className="border-t border-white/10 bg-bg-panel/60 py-8 text-center text-sm text-gray-500">
            © {new Date().getFullYear()} NeonShop. Alle Rechte vorbehalten.
          </footer>
        </AuthProvider>
      </body>
    </html>
  );
}
