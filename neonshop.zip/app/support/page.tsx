"use client";

import { useEffect } from "react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/components/AuthProvider";
import { LifeBuoy } from "lucide-react";
import Link from "next/link";

export default function SupportPage() {
  const { user, loading } = useAuth();
  const router = useRouter();

  useEffect(() => {
    if (loading) return;
    if (user) router.push("/dashboard/tickets");
  }, [loading, user, router]);

  if (loading || user) {
    return <div className="mx-auto max-w-lg px-4 py-20 text-center text-gray-500">Lädt...</div>;
  }

  return (
    <div className="mx-auto max-w-lg px-4 py-24 text-center">
      <LifeBuoy className="mx-auto h-12 w-12 text-neon-blue" />
      <h1 className="mt-4 font-display text-2xl font-bold text-white">Support</h1>
      <p className="mt-2 text-gray-400">
        Logge dich ein, um ein Support-Ticket zu erstellen oder bestehende Anfragen einzusehen.
      </p>
      <Link href="/login?redirect=/dashboard/tickets" className="neon-btn mt-6 inline-flex">
        Jetzt einloggen
      </Link>
    </div>
  );
}
