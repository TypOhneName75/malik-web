import Link from "next/link";
import { ArrowRight, ShieldCheck, Zap, Wallet } from "lucide-react";
import { prisma } from "@/lib/prisma";
import ProductCard from "@/components/ProductCard";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  const [categories, latestProducts] = await Promise.all([
    prisma.category.findMany({ include: { subcategories: true } }),
    prisma.product.findMany({
      where: { isActive: true },
      orderBy: { createdAt: "desc" },
      take: 8,
      include: { category: true, subcategory: true },
    }),
  ]);

  return (
    <div>
      {/* Hero */}
      <section className="relative overflow-hidden px-4 py-24 text-center md:px-8">
        <div className="pointer-events-none absolute inset-0 -z-10">
          <div className="absolute left-1/2 top-0 h-[500px] w-[500px] -translate-x-1/2 rounded-full bg-neon-blue/10 blur-[120px]" />
          <div className="absolute bottom-0 right-1/4 h-[400px] w-[400px] rounded-full bg-neon-purple/10 blur-[120px]" />
        </div>
        <span className="badge mb-4 border border-neon-blue/40 bg-neon-blue/10 text-neon-blue">
          Dark Mode · Neon Edition
        </span>
        <h1 className="mx-auto max-w-3xl font-display text-4xl font-black leading-tight text-white md:text-6xl">
          Level Up Your{" "}
          <span className="bg-gradient-to-r from-neon-blue via-neon-purple to-neon-pink bg-clip-text text-transparent">
            Style & Gear
          </span>
        </h1>
        <p className="mx-auto mt-6 max-w-xl text-gray-400">
          Digitale Produkte und Streetwear in einem Shop. Sicher bezahlen mit
          deinem Wallet, sofort verfügbar.
        </p>
        <div className="mt-8 flex justify-center gap-4">
          <Link href="/shop" className="neon-btn">
            Shop entdecken <ArrowRight className="h-4 w-4" />
          </Link>
          <Link href="/register" className="neon-btn-outline">
            Account erstellen
          </Link>
        </div>

        <div className="mx-auto mt-16 grid max-w-3xl grid-cols-1 gap-4 sm:grid-cols-3">
          <div className="glass-card p-5 text-left">
            <ShieldCheck className="h-6 w-6 text-neon-blue" />
            <p className="mt-2 text-sm font-semibold text-white">Sicher bezahlen</p>
            <p className="text-xs text-gray-500">Verschlüsselt & geschützt</p>
          </div>
          <div className="glass-card p-5 text-left">
            <Zap className="h-6 w-6 text-neon-purple" />
            <p className="mt-2 text-sm font-semibold text-white">Sofort verfügbar</p>
            <p className="text-xs text-gray-500">Digitale Produkte direkt</p>
          </div>
          <div className="glass-card p-5 text-left">
            <Wallet className="h-6 w-6 text-neon-green" />
            <p className="mt-2 text-sm font-semibold text-white">Eigenes Wallet</p>
            <p className="text-xs text-gray-500">Guthaben aufladen & verwalten</p>
          </div>
        </div>
      </section>

      {/* Kategorien */}
      <section className="mx-auto max-w-7xl px-4 py-12 md:px-8">
        <h2 className="font-display text-2xl font-bold text-white">Kategorien</h2>
        <div className="mt-6 grid grid-cols-1 gap-6 sm:grid-cols-2">
          {categories.map((cat) => (
            <Link
              key={cat.id}
              href={`/shop?category=${cat.slug}`}
              className="glass-card group relative overflow-hidden p-8 transition-all hover:border-neon-purple/40 hover:shadow-neon-purple"
            >
              <h3 className="font-display text-xl font-bold text-white group-hover:text-neon-purple transition-colors">
                {cat.name}
              </h3>
              <p className="mt-2 text-sm text-gray-500">
                {cat.subcategories.map((s) => s.name).join(" · ")}
              </p>
              <ArrowRight className="mt-4 h-5 w-5 text-gray-600 transition-transform group-hover:translate-x-2 group-hover:text-neon-purple" />
            </Link>
          ))}
        </div>
      </section>

      {/* Neue Produkte */}
      {latestProducts.length > 0 && (
        <section className="mx-auto max-w-7xl px-4 py-12 md:px-8">
          <div className="flex items-center justify-between">
            <h2 className="font-display text-2xl font-bold text-white">Neu im Shop</h2>
            <Link href="/shop" className="nav-link">Alle ansehen →</Link>
          </div>
          <div className="mt-6 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
            {latestProducts.map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
