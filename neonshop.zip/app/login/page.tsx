"use client";

import { useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import Link from "next/link";
import { Zap, Lock, User as UserIcon } from "lucide-react";
import { useAuth } from "@/components/AuthProvider";

export default function LoginPage() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { refresh } = useAuth();

  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError("");

    const res = await fetch("/api/auth/login", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ username, password }),
    });
    const data = await res.json();
    setLoading(false);

    if (!res.ok) {
      setError(data.error ?? "Login fehlgeschlagen");
      return;
    }

    await refresh();
    router.push(searchParams.get("redirect") ?? "/dashboard");
  }

  return (
    <div className="mx-auto flex min-h-[80vh] max-w-md items-center px-4">
      <div className="glass-card w-full p-8">
        <div className="flex justify-center">
          <Zap className="h-10 w-10 text-neon-blue drop-shadow-[0_0_8px_rgba(0,229,255,0.8)]" />
        </div>
        <h1 className="mt-4 text-center font-display text-2xl font-bold text-white">
          Willkommen zurück
        </h1>
        <p className="mt-1 text-center text-sm text-gray-500">
          Logge dich in deinen Account ein
        </p>

        <form onSubmit={handleSubmit} className="mt-6 space-y-4">
          <div className="relative">
            <UserIcon className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-500" />
            <input
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="Username"
              required
              className="neon-input pl-10"
            />
          </div>
          <div className="relative">
            <Lock className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-500" />
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Passwort"
              required
              className="neon-input pl-10"
            />
          </div>

          {error && <p className="text-sm text-red-400">{error}</p>}

          <button type="submit" disabled={loading} className="neon-btn w-full justify-center">
            {loading ? "Wird eingeloggt..." : "Einloggen"}
          </button>
        </form>

        <p className="mt-6 text-center text-sm text-gray-500">
          Noch keinen Account?{" "}
          <Link href="/register" className="text-neon-blue hover:underline">
            Jetzt registrieren
          </Link>
        </p>
      </div>
    </div>
  );
}
