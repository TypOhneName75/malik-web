"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Trash2, Minus, Plus, ShoppingBag } from "lucide-react";
import { formatPrice } from "@/lib/format";
import { useAuth } from "@/components/AuthProvider";

interface CartItem {
  id: string;
  quantity: number;
  product: { id: string; title: string; priceCents: number; images: string[]; stock: number };
}

export default function CartPage() {
  const { user, loading: authLoading } = useAuth();
  const router = useRouter();
  const [items, setItems] = useState<CartItem[]>([]);
  const [totalCents, setTotalCents] = useState(0);
  const [balanceCents, setBalanceCents] = useState(0);
  const [loading, setLoading] = useState(true);

  async function loadCart() {
    const res = await fetch("/api/cart");
    if (res.ok) {
      const d = await res.json();
      setItems(d.items ?? []);
      setTotalCents(d.totalCents ?? 0);
      setBalanceCents(d.balanceCents ?? 0);
    }
    setLoading(false);
  }

  useEffect(() => {
    if (authLoading) return;
    if (!user) {
      router.push("/login?redirect=/cart");
      return;
    }
    loadCart();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [authLoading, user]);

  async function updateQuantity(itemId: string, quantity: number) {
    if (quantity < 1) return;
    await fetch(`/api/cart/${itemId}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ quantity }),
    });
    loadCart();
  }

  async function removeItem(itemId: string) {
    await fetch(`/api/cart/${itemId}`, { method: "DELETE" });
    loadCart();
  }

  if (loading) {
    return <div className="mx-auto max-w-4xl px-4 py-20 text-center text-gray-500">Lädt...</div>;
  }

  return (
    <div className="mx-auto max-w-4xl px-4 py-10 md:px-8">
      <h1 className="font-display text-3xl font-bold text-white">Warenkorb</h1>

      {items.length === 0 ? (
        <div className="glass-card mt-8 flex flex-col items-center gap-4 p-16 text-center">
          <ShoppingBag className="h-12 w-12 text-gray-600" />
          <p className="text-gray-500">Dein Warenkorb ist leer.</p>
          <Link href="/shop" className="neon-btn">Jetzt shoppen</Link>
        </div>
      ) : (
        <div className="mt-8 grid grid-cols-1 gap-8 md:grid-cols-3">
          <div className="space-y-4 md:col-span-2">
            {items.map((item) => (
              <div key={item.id} className="glass-card flex items-center gap-4 p-4">
                <div className="h-20 w-20 flex-shrink-0 overflow-hidden rounded-xl bg-bg-panel">
                  {item.product.images?.[0] && (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img src={item.product.images[0]} alt="" className="h-full w-full object-cover" />
                  )}
                </div>
                <div className="flex-1">
                  <Link href={`/product/${item.product.id}`} className="font-semibold text-gray-100 hover:text-neon-blue">
                    {item.product.title}
                  </Link>
                  <p className="text-sm text-neon-green">{formatPrice(item.product.priceCents)}</p>
                </div>
                <div className="flex items-center gap-2 rounded-lg border border-white/10 px-2 py-1">
                  <button onClick={() => updateQuantity(item.id, item.quantity - 1)} className="text-gray-400 hover:text-white">
                    <Minus className="h-3.5 w-3.5" />
                  </button>
                  <span className="w-6 text-center text-sm">{item.quantity}</span>
                  <button
                    onClick={() => updateQuantity(item.id, item.quantity + 1)}
                    disabled={item.quantity >= item.product.stock}
                    className="text-gray-400 hover:text-white disabled:opacity-30"
                  >
                    <Plus className="h-3.5 w-3.5" />
                  </button>
                </div>
                <button onClick={() => removeItem(item.id)} className="text-gray-500 hover:text-red-400">
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            ))}
          </div>

          <div className="glass-card h-fit p-6">
            <h2 className="font-display font-bold text-white">Zusammenfassung</h2>
            <div className="mt-4 flex justify-between text-sm text-gray-400">
              <span>Zwischensumme</span>
              <span>{formatPrice(totalCents)}</span>
            </div>
            <div className="mt-2 flex justify-between text-sm text-gray-400">
              <span>Dein Guthaben</span>
              <span className={balanceCents < totalCents ? "text-red-400" : "text-neon-green"}>
                {formatPrice(balanceCents)}
              </span>
            </div>
            <div className="mt-4 flex justify-between border-t border-white/10 pt-4 font-bold text-white">
              <span>Gesamt</span>
              <span>{formatPrice(totalCents)}</span>
            </div>

            {balanceCents < totalCents && (
              <p className="mt-3 text-xs text-red-400">
                Guthaben reicht nicht aus.{" "}
                <Link href="/dashboard/wallet" className="underline">Wallet aufladen</Link>
              </p>
            )}

            <Link
              href="/checkout"
              className="neon-btn mt-6 w-full justify-center"
            >
              Zur Kasse
            </Link>
          </div>
        </div>
      )}
    </div>
  );
}
