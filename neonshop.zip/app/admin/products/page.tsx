"use client";

import { useEffect, useState } from "react";
import { Plus, Pencil, Trash2, X } from "lucide-react";
import { formatPrice } from "@/lib/format";

interface Category { id: string; name: string; subcategories: { id: string; name: string }[]; }
interface Product {
  id: string; title: string; description: string; priceCents: number; stock: number;
  images: string[]; isActive: boolean;
  category: { id: string; name: string }; subcategory: { id: string; name: string };
}

const emptyForm = {
  title: "", description: "", priceEuro: "", stock: "0",
  categoryId: "", subcategoryId: "", imagesText: "", isActive: true,
};

export default function AdminProductsPage() {
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState(emptyForm);
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);

  async function load() {
    const [pRes, cRes] = await Promise.all([
      fetch("/api/admin/products"),
      fetch("/api/categories"),
    ]);
    setProducts((await pRes.json()).products ?? []);
    setCategories((await cRes.json()).categories ?? []);
  }

  useEffect(() => { load(); }, []);

  function startCreate() {
    setEditingId(null);
    setForm(emptyForm);
    setShowForm(true);
    setError("");
  }

  function startEdit(p: Product) {
    setEditingId(p.id);
    setForm({
      title: p.title,
      description: p.description,
      priceEuro: (p.priceCents / 100).toString(),
      stock: p.stock.toString(),
      categoryId: p.category.id,
      subcategoryId: p.subcategory.id,
      imagesText: p.images.join("\n"),
      isActive: p.isActive,
    });
    setShowForm(true);
    setError("");
  }

  const selectedCategory = categories.find((c) => c.id === form.categoryId);

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    setError("");

    const priceCents = Math.round(parseFloat(form.priceEuro) * 100);
    if (isNaN(priceCents) || priceCents < 0) {
      setError("Ungültiger Preis");
      return;
    }
    if (!form.categoryId || !form.subcategoryId) {
      setError("Bitte Kategorie und Unterkategorie wählen");
      return;
    }

    const payload = {
      title: form.title,
      description: form.description,
      priceCents,
      stock: parseInt(form.stock, 10) || 0,
      categoryId: form.categoryId,
      subcategoryId: form.subcategoryId,
      images: form.imagesText.split("\n").map((s) => s.trim()).filter(Boolean),
      isActive: form.isActive,
    };

    setSubmitting(true);
    const res = editingId
      ? await fetch(`/api/admin/products/${editingId}`, {
          method: "PATCH",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        })
      : await fetch("/api/admin/products", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        });
    const data = await res.json();
    setSubmitting(false);

    if (!res.ok) {
      setError(data.error ?? "Fehler beim Speichern");
      return;
    }

    setShowForm(false);
    load();
  }

  async function handleDelete(id: string) {
    if (!confirm("Produkt wirklich löschen?")) return;
    await fetch(`/api/admin/products/${id}`, { method: "DELETE" });
    load();
  }

  return (
    <div>
      <div className="flex items-center justify-between">
        <h1 className="font-display text-2xl font-bold text-white">Produkte</h1>
        <button onClick={startCreate} className="neon-btn">
          <Plus className="h-4 w-4" /> Neues Produkt
        </button>
      </div>

      {showForm && (
        <form onSubmit={handleSubmit} className="glass-card mt-6 space-y-4 p-6">
          <div className="flex items-center justify-between">
            <h2 className="font-display font-bold text-white">
              {editingId ? "Produkt bearbeiten" : "Neues Produkt"}
            </h2>
            <button type="button" onClick={() => setShowForm(false)}>
              <X className="h-4 w-4 text-gray-500" />
            </button>
          </div>

          <input
            value={form.title}
            onChange={(e) => setForm({ ...form, title: e.target.value })}
            placeholder="Titel"
            required
            className="neon-input"
          />
          <textarea
            value={form.description}
            onChange={(e) => setForm({ ...form, description: e.target.value })}
            placeholder="Beschreibung"
            required
            rows={3}
            className="neon-input"
          />
          <div className="grid grid-cols-2 gap-4">
            <input
              type="number"
              step="0.01"
              value={form.priceEuro}
              onChange={(e) => setForm({ ...form, priceEuro: e.target.value })}
              placeholder="Preis (€)"
              required
              className="neon-input"
            />
            <input
              type="number"
              value={form.stock}
              onChange={(e) => setForm({ ...form, stock: e.target.value })}
              placeholder="Lagerbestand"
              required
              className="neon-input"
            />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <select
              value={form.categoryId}
              onChange={(e) => setForm({ ...form, categoryId: e.target.value, subcategoryId: "" })}
              required
              className="neon-input"
            >
              <option value="">Kategorie wählen</option>
              {categories.map((c) => (
                <option key={c.id} value={c.id}>{c.name}</option>
              ))}
            </select>
            <select
              value={form.subcategoryId}
              onChange={(e) => setForm({ ...form, subcategoryId: e.target.value })}
              required
              disabled={!selectedCategory}
              className="neon-input"
            >
              <option value="">Unterkategorie wählen</option>
              {selectedCategory?.subcategories.map((s) => (
                <option key={s.id} value={s.id}>{s.name}</option>
              ))}
            </select>
          </div>
          <textarea
            value={form.imagesText}
            onChange={(e) => setForm({ ...form, imagesText: e.target.value })}
            placeholder="Bild-URLs (eine pro Zeile)"
            rows={2}
            className="neon-input"
          />
          <label className="flex items-center gap-2 text-sm text-gray-400">
            <input
              type="checkbox"
              checked={form.isActive}
              onChange={(e) => setForm({ ...form, isActive: e.target.checked })}
            />
            Produkt aktiv (im Shop sichtbar)
          </label>

          {error && <p className="text-sm text-red-400">{error}</p>}

          <button type="submit" disabled={submitting} className="neon-btn w-full justify-center">
            {submitting ? "Wird gespeichert..." : editingId ? "Änderungen speichern" : "Produkt erstellen"}
          </button>
        </form>
      )}

      <div className="mt-6 space-y-2">
        {products.map((p) => (
          <div key={p.id} className="glass-card flex items-center justify-between p-4">
            <div className="flex items-center gap-3">
              <div className="h-12 w-12 flex-shrink-0 overflow-hidden rounded-lg bg-bg-panel">
                {p.images?.[0] && (
                  // eslint-disable-next-line @next/next/no-img-element
                  <img src={p.images[0]} alt="" className="h-full w-full object-cover" />
                )}
              </div>
              <div>
                <p className="text-sm font-semibold text-gray-100">{p.title}</p>
                <p className="text-xs text-gray-500">
                  {p.category.name} / {p.subcategory.name} · Lager: {p.stock}
                  {!p.isActive && <span className="ml-2 text-red-400">(inaktiv)</span>}
                </p>
              </div>
            </div>
            <div className="flex items-center gap-3">
              <span className="text-sm text-neon-green">{formatPrice(p.priceCents)}</span>
              <button onClick={() => startEdit(p)} className="text-gray-500 hover:text-neon-blue">
                <Pencil className="h-4 w-4" />
              </button>
              <button onClick={() => handleDelete(p.id)} className="text-gray-500 hover:text-red-400">
                <Trash2 className="h-4 w-4" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
