"use client";

import { useEffect, useState } from "react";
import { Plus, Trash2 } from "lucide-react";

interface Subcategory { id: string; name: string; slug: string; }
interface Category { id: string; name: string; slug: string; subcategories: Subcategory[]; }

function slugify(text: string) {
  return text
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "");
}

export default function AdminCategoriesPage() {
  const [categories, setCategories] = useState<Category[]>([]);
  const [newCategoryName, setNewCategoryName] = useState("");
  const [subInputs, setSubInputs] = useState<Record<string, string>>({});
  const [error, setError] = useState("");

  async function load() {
    const res = await fetch("/api/admin/categories");
    const d = await res.json();
    setCategories(d.categories ?? []);
  }

  useEffect(() => { load(); }, []);

  async function addCategory(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    if (!newCategoryName.trim()) return;
    const res = await fetch("/api/admin/categories", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name: newCategoryName, slug: slugify(newCategoryName) }),
    });
    const data = await res.json();
    if (!res.ok) {
      setError(data.error ?? "Fehler beim Erstellen");
      return;
    }
    setNewCategoryName("");
    load();
  }

  async function deleteCategory(id: string) {
    if (!confirm("Kategorie inkl. aller Unterkategorien löschen? Zugehörige Produkte müssen zuvor entfernt werden.")) return;
    const res = await fetch(`/api/admin/categories/${id}`, { method: "DELETE" });
    if (!res.ok) {
      const d = await res.json().catch(() => ({}));
      alert(d.error ?? "Löschen fehlgeschlagen (evtl. noch Produkte zugeordnet)");
      return;
    }
    load();
  }

  async function addSubcategory(categoryId: string) {
    const name = subInputs[categoryId]?.trim();
    if (!name) return;
    const res = await fetch("/api/admin/subcategories", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name, slug: slugify(name), categoryId }),
    });
    if (res.ok) {
      setSubInputs({ ...subInputs, [categoryId]: "" });
      load();
    }
  }

  async function deleteSubcategory(id: string) {
    if (!confirm("Unterkategorie löschen?")) return;
    const res = await fetch(`/api/admin/subcategories/${id}`, { method: "DELETE" });
    if (!res.ok) {
      const d = await res.json().catch(() => ({}));
      alert(d.error ?? "Löschen fehlgeschlagen (evtl. noch Produkte zugeordnet)");
      return;
    }
    load();
  }

  return (
    <div>
      <h1 className="font-display text-2xl font-bold text-white">Kategorien</h1>

      <form onSubmit={addCategory} className="glass-card mt-6 flex gap-3 p-4">
        <input
          value={newCategoryName}
          onChange={(e) => setNewCategoryName(e.target.value)}
          placeholder="Neue Hauptkategorie..."
          className="neon-input flex-1"
        />
        <button type="submit" className="neon-btn">
          <Plus className="h-4 w-4" /> Hinzufügen
        </button>
      </form>
      {error && <p className="mt-2 text-sm text-red-400">{error}</p>}

      <div className="mt-6 space-y-4">
        {categories.map((cat) => (
          <div key={cat.id} className="glass-card p-5">
            <div className="flex items-center justify-between">
              <h2 className="font-display font-bold text-white">{cat.name}</h2>
              <button onClick={() => deleteCategory(cat.id)} className="text-gray-500 hover:text-red-400">
                <Trash2 className="h-4 w-4" />
              </button>
            </div>

            <div className="mt-3 flex flex-wrap gap-2">
              {cat.subcategories.map((sub) => (
                <span key={sub.id} className="badge flex items-center gap-1 border border-white/10 text-gray-300">
                  {sub.name}
                  <button onClick={() => deleteSubcategory(sub.id)} className="text-gray-500 hover:text-red-400">
                    <Trash2 className="h-3 w-3" />
                  </button>
                </span>
              ))}
            </div>

            <div className="mt-3 flex gap-2">
              <input
                value={subInputs[cat.id] ?? ""}
                onChange={(e) => setSubInputs({ ...subInputs, [cat.id]: e.target.value })}
                placeholder="Neue Unterkategorie..."
                className="neon-input flex-1 text-sm"
              />
              <button onClick={() => addSubcategory(cat.id)} className="neon-btn-outline">
                <Plus className="h-3.5 w-3.5" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
