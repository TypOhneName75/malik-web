"use client";

import { useEffect, useState } from "react";
import { formatPrice } from "@/lib/format";

interface Order {
  id: string;
  totalCents: number;
  status: string;
  createdAt: string;
  user: { username: string };
  items: { title: string; quantity: number }[];
}

const statusColors: Record<string, string> = {
  PENDING: "bg-yellow-500/10 text-yellow-400",
  PAID: "bg-neon-green/10 text-neon-green",
  CANCELLED: "bg-gray-500/10 text-gray-400",
  REFUNDED: "bg-red-500/10 text-red-400",
};
const statusLabels: Record<string, string> = {
  PENDING: "Ausstehend", PAID: "Bezahlt", CANCELLED: "Storniert", REFUNDED: "Erstattet",
};

export default function AdminOrdersPage() {
  const [orders, setOrders] = useState<Order[]>([]);

  useEffect(() => {
    fetch("/api/admin/orders").then((r) => r.json()).then((d) => setOrders(d.orders ?? []));
  }, []);

  return (
    <div>
      <h1 className="font-display text-2xl font-bold text-white">Bestellungen</h1>
      <div className="mt-6 space-y-2">
        {orders.map((o) => (
          <div key={o.id} className="glass-card p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-semibold text-gray-100">#{o.id.slice(-8)} · {o.user.username}</p>
                <p className="text-xs text-gray-500">
                  {o.items.map((i) => `${i.title} ×${i.quantity}`).join(", ")}
                </p>
              </div>
              <div className="flex items-center gap-3">
                <span className={`badge ${statusColors[o.status]}`}>{statusLabels[o.status] ?? o.status}</span>
                <span className="text-sm font-semibold text-white">{formatPrice(o.totalCents)}</span>
              </div>
            </div>
          </div>
        ))}
        {orders.length === 0 && <p className="text-sm text-gray-500">Noch keine Bestellungen.</p>}
      </div>
    </div>
  );
}
