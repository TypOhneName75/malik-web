"use client";

import { useEffect, useState } from "react";
import Link from "next/link";

interface Ticket {
  id: string;
  subject: string;
  category: string;
  status: string;
  updatedAt: string;
  user: { username: string };
}

const statusColors: Record<string, string> = {
  OPEN: "bg-neon-blue/10 text-neon-blue",
  IN_PROGRESS: "bg-yellow-500/10 text-yellow-400",
  CLOSED: "bg-gray-500/10 text-gray-400",
};
const statusLabels: Record<string, string> = {
  OPEN: "Offen", IN_PROGRESS: "In Bearbeitung", CLOSED: "Geschlossen",
};

export default function AdminTicketsPage() {
  const [tickets, setTickets] = useState<Ticket[]>([]);

  useEffect(() => {
    fetch("/api/admin/tickets").then((r) => r.json()).then((d) => setTickets(d.tickets ?? []));
  }, []);

  return (
    <div>
      <h1 className="font-display text-2xl font-bold text-white">Support-Tickets</h1>
      <div className="mt-6 space-y-2">
        {tickets.map((t) => (
          <Link key={t.id} href={`/admin/tickets/${t.id}`} className="glass-card flex items-center justify-between p-4 hover:border-neon-blue/40">
            <div>
              <p className="text-sm font-semibold text-gray-100">{t.subject}</p>
              <p className="text-xs text-gray-500">{t.user.username} · {t.category}</p>
            </div>
            <span className={`badge ${statusColors[t.status]}`}>{statusLabels[t.status]}</span>
          </Link>
        ))}
        {tickets.length === 0 && <p className="text-sm text-gray-500">Keine Tickets vorhanden.</p>}
      </div>
    </div>
  );
}
