"use client";

import { useEffect, useState, useRef } from "react";
import { useParams } from "next/navigation";
import Link from "next/link";
import { ChevronLeft, Send } from "lucide-react";

interface Reply { id: string; author: "USER" | "ADMIN"; message: string; createdAt: string; }
interface TicketDetail {
  id: string; subject: string; category: string; status: string; replies: Reply[];
}

const statusOptions = ["OPEN", "IN_PROGRESS", "CLOSED"] as const;
const statusLabels: Record<string, string> = {
  OPEN: "Offen", IN_PROGRESS: "In Bearbeitung", CLOSED: "Geschlossen",
};

export default function AdminTicketDetailPage() {
  const params = useParams<{ id: string }>();
  const [ticket, setTicket] = useState<TicketDetail | null>(null);
  const [message, setMessage] = useState("");
  const [sending, setSending] = useState(false);
  const bottomRef = useRef<HTMLDivElement>(null);

  async function load() {
    const res = await fetch(`/api/tickets/${params.id}`);
    if (res.ok) setTicket((await res.json()).ticket);
  }

  useEffect(() => { load(); }, [params.id]);
  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: "smooth" }); }, [ticket?.replies?.length]);

  async function sendReply(e: React.FormEvent) {
    e.preventDefault();
    if (!message.trim()) return;
    setSending(true);
    await fetch(`/api/tickets/${params.id}/reply`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ message }),
    });
    setMessage("");
    setSending(false);
    load();
  }

  async function changeStatus(status: string) {
    await fetch(`/api/admin/tickets/${params.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ status }),
    });
    load();
  }

  if (!ticket) return <div className="text-center text-gray-500 py-20">Lädt...</div>;

  return (
    <div>
      <Link href="/admin/tickets" className="flex items-center gap-1 text-sm text-gray-500 hover:text-white">
        <ChevronLeft className="h-4 w-4" /> Zurück zu Tickets
      </Link>

      <div className="mt-4 flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="font-display text-2xl font-bold text-white">{ticket.subject}</h1>
          <p className="text-sm text-gray-500">{ticket.category}</p>
        </div>
        <select
          value={ticket.status}
          onChange={(e) => changeStatus(e.target.value)}
          className="neon-input w-auto"
        >
          {statusOptions.map((s) => (
            <option key={s} value={s}>{statusLabels[s]}</option>
          ))}
        </select>
      </div>

      <div className="glass-card mt-6 flex max-h-[50vh] flex-col gap-3 overflow-y-auto p-4">
        {ticket.replies.map((r) => (
          <div
            key={r.id}
            className={`max-w-[80%] rounded-2xl px-4 py-2.5 text-sm ${
              r.author === "ADMIN" ? "self-end bg-neon-purple/10 text-gray-200" : "self-start bg-neon-blue/10 text-gray-200"
            }`}
          >
            <p className="mb-1 text-xs font-semibold text-gray-500">
              {r.author === "ADMIN" ? "Support-Team" : "Kunde"}
            </p>
            {r.message}
          </div>
        ))}
        <div ref={bottomRef} />
      </div>

      {ticket.status !== "CLOSED" && (
        <form onSubmit={sendReply} className="mt-4 flex gap-2">
          <input
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            placeholder="Antwort schreiben..."
            className="neon-input flex-1"
          />
          <button type="submit" disabled={sending} className="neon-btn">
            <Send className="h-4 w-4" />
          </button>
        </form>
      )}
    </div>
  );
}
