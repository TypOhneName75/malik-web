"use client";

import { useEffect } from "react";
import { useRouter, usePathname } from "next/navigation";
import Link from "next/link";
import {
  LayoutDashboard,
  Package,
  FolderTree,
  ShoppingBag,
  Users,
  LifeBuoy,
} from "lucide-react";
import { useAuth } from "@/components/AuthProvider";

const navItems = [
  { href: "/admin", label: "Übersicht", icon: LayoutDashboard },
  { href: "/admin/products", label: "Produkte", icon: Package },
  { href: "/admin/categories", label: "Kategorien", icon: FolderTree },
  { href: "/admin/orders", label: "Bestellungen", icon: ShoppingBag },
  { href: "/admin/users", label: "Benutzer", icon: Users },
  { href: "/admin/tickets", label: "Support-Tickets", icon: LifeBuoy },
];

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  const { user, loading } = useAuth();
  const router = useRouter();
  const pathname = usePathname();

  useEffect(() => {
    if (loading) return;
    if (!user || user.role !== "ADMIN") {
      router.push("/login?redirect=/admin");
    }
  }, [loading, user, router]);

  if (loading || !user || user.role !== "ADMIN") {
    return <div className="mx-auto max-w-5xl px-4 py-20 text-center text-gray-500">Lädt...</div>;
  }

  return (
    <div className="mx-auto flex max-w-7xl gap-6 px-4 py-8 md:px-8">
      <aside className="hidden w-56 flex-shrink-0 md:block">
        <div className="glass-card sticky top-20 p-3">
          <p className="px-3 py-2 font-display text-xs font-bold uppercase tracking-widest text-neon-purple">
            Admin Panel
          </p>
          <nav className="space-y-1">
            {navItems.map((item) => {
              const active = pathname === item.href;
              const Icon = item.icon;
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  className={`flex items-center gap-2 rounded-lg px-3 py-2 text-sm transition-colors ${
                    active
                      ? "bg-neon-purple/10 text-neon-purple"
                      : "text-gray-400 hover:bg-white/5 hover:text-white"
                  }`}
                >
                  <Icon className="h-4 w-4" /> {item.label}
                </Link>
              );
            })}
          </nav>
        </div>
      </aside>
      <div className="flex-1">{children}</div>
    </div>
  );
}
