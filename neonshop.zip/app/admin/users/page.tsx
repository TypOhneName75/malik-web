"use client";

import { useEffect, useState } from "react";
import { Ban, CheckCircle, Plus, Minus } from "lucide-react";
import { formatPrice } from "@/lib/format";

interface AdminUser {
  id: string;
  username: string;
  role: "USER" | "ADMIN";
  balanceCents: number;
  isBanned: boolean;
  createdAt: string;
  _count: { orders: number; tickets: number };
}

export default function AdminUsersPage() {
  const [users, setUsers] = useState<AdminUser[]>([]);
  const [adjustAmounts, setAdjustAmounts] = useState<Record<string, string>>({});

  async function load() {
    const res = await fetch("/api/admin/users");
    const d = await res.json();
    setUsers(d.users ?? []);
  }

  useEffect(() => { load(); }, []);

  async function toggleBan(user: AdminUser) {
    await fetch(`/api/admin/users/${user.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ isBanned: !user.isBanned }),
    });
    load();
  }

  async function adjustBalance(userId: string, sign: 1 | -1) {
    const euroAmount = parseFloat(adjustAmounts[userId] ?? "0");
    if (!euroAmount || euroAmount <= 0) return;
    const balanceAdjustmentCents = Math.round(euroAmount * 100) * sign;
    await fetch(`/api/admin/users/${userId}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ balanceAdjustmentCents }),
    });
    setAdjustAmounts({ ...adjustAmounts, [userId]: "" });
    load();
  }

  return (
    <div>
      <h1 className="font-display text-2xl font-bold text-white">Benutzer</h1>
      <div className="mt-6 space-y-3">
        {users.map((u) => (
          <div key={u.id} className="glass-card p-4">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <p className="flex items-center gap-2 text-sm font-semibold text-gray-100">
                  {u.username}
                  {u.role === "ADMIN" && <span className="badge bg-neon-purple/10 text-neon-purple">Admin</span>}
                  {u.isBanned && <span className="badge bg-red-500/10 text-red-400">Gesperrt</span>}
                </p>
                <p className="text-xs text-gray-500">
                  {u._count.orders} Bestellungen · {u._count.tickets} Tickets
                </p>
              </div>
              <span className="text-sm text-neon-green">{formatPrice(u.balanceCents)}</span>
            </div>

            <div className="mt-3 flex flex-wrap items-center gap-2">
              <input
                type="number"
                step="0.01"
                placeholder="Betrag (€)"
                value={adjustAmounts[u.id] ?? ""}
                onChange={(e) => setAdjustAmounts({ ...adjustAmounts, [u.id]: e.target.value })}
                className="neon-input w-32 text-sm"
              />
              <button onClick={() => adjustBalance(u.id, 1)} className="neon-btn-outline !px-3 !py-1.5 text-xs">
                <Plus className="h-3.5 w-3.5" /> Gutschrift
              </button>
              <button onClick={() => adjustBalance(u.id, -1)} className="neon-btn-outline !px-3 !py-1.5 text-xs">
                <Minus className="h-3.5 w-3.5" /> Abbuchung
              </button>
              {u.role !== "ADMIN" && (
                <button
                  onClick={() => toggleBan(u)}
                  className={`ml-auto flex items-center gap-1 rounded-lg px-3 py-1.5 text-xs ${
                    u.isBanned
                      ? "text-neon-green hover:bg-neon-green/10"
                      : "text-red-400 hover:bg-red-500/10"
                  }`}
                >
                  {u.isBanned ? <CheckCircle className="h-3.5 w-3.5" /> : <Ban className="h-3.5 w-3.5" />}
                  {u.isBanned ? "Entsperren" : "Sperren"}
                </button>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
