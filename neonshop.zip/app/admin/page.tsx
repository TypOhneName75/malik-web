"use client";

import { useEffect, useState } from "react";
import { Users, Package, ShoppingBag, LifeBuoy, TrendingUp } from "lucide-react";
import { formatPrice } from "@/lib/format";

interface Stats {
  userCount: number;
  productCount: number;
  orderCount: number;
  openTickets: number;
  revenueCents: number;
}

export default function AdminDashboard() {
  const [stats, setStats] = useState<Stats | null>(null);

  useEffect(() => {
    fetch("/api/admin/stats").then((r) => r.json()).then(setStats);
  }, []);

  const cards = stats
    ? [
        { label: "Umsatz", value: formatPrice(stats.revenueCents), icon: TrendingUp, color: "text-neon-green" },
        { label: "Bestellungen", value: stats.orderCount, icon: ShoppingBag, color: "text-neon-blue" },
        { label: "Benutzer", value: stats.userCount, icon: Users, color: "text-neon-purple" },
        { label: "Produkte", value: stats.productCount, icon: Package, color: "text-neon-pink" },
        { label: "Offene Tickets", value: stats.openTickets, icon: LifeBuoy, color: "text-yellow-400" },
      ]
    : [];

  return (
    <div>
      <h1 className="font-display text-2xl font-bold text-white">Übersicht</h1>
      <div className="mt-6 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-5">
        {stats ? (
          cards.map((c) => (
            <div key={c.label} className="glass-card p-5">
              <c.icon className={`h-5 w-5 ${c.color}`} />
              <p className="mt-2 text-xs text-gray-500">{c.label}</p>
              <p className="font-display text-xl font-bold text-white">{c.value}</p>
            </div>
          ))
        ) : (
          Array.from({ length: 5 }).map((_, i) => (
            <div key={i} className="glass-card h-24 animate-pulse" />
          ))
        )}
      </div>
    </div>
  );
}
