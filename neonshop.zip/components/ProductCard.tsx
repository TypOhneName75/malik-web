"use client";

import Link from "next/link";
import { ShoppingCart, PackageX } from "lucide-react";
import { formatPrice } from "@/lib/format";
import { useAuth } from "./AuthProvider";
import { useState } from "react";

interface Product {
  id: string;
  title: string;
  priceCents: number;
  images: string[];
  stock: number;
  category?: { name: string };
  subcategory?: { name: string };
}

export default function ProductCard({ product }: { product: Product }) {
  const { user, refresh } = useAuth();
  const [adding, setAdding] = useState(false);
  const [added, setAdded] = useState(false);

  async function addToCart(e: React.MouseEvent) {
    e.preventDefault();
    if (!user) {
      window.location.href = "/login";
      return;
    }
    setAdding(true);
    const res = await fetch("/api/cart", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ productId: product.id, quantity: 1 }),
    });
    setAdding(false);
    if (res.ok) {
      setAdded(true);
      setTimeout(() => setAdded(false), 1500);
    }
  }

  return (
    <Link
      href={`/product/${product.id}`}
      className="group glass-card fade-in-up overflow-hidden transition-all duration-300 hover:-translate-y-1 hover:border-neon-blue/40 hover:shadow-neon-blue"
    >
      <div className="relative aspect-square overflow-hidden bg-bg-panel">
        {product.images?.[0] ? (
          // eslint-disable-next-line @next/next/no-img-element
          <img
            src={product.images[0]}
            alt={product.title}
            className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-110"
          />
        ) : (
          <div className="flex h-full items-center justify-center text-gray-600">
            <PackageX className="h-10 w-10" />
          </div>
        )}
        {product.stock === 0 && (
          <span className="absolute right-2 top-2 badge bg-red-500/20 text-red-400">
            Ausverkauft
          </span>
        )}
        {product.subcategory?.name && (
          <span className="absolute left-2 top-2 badge bg-black/50 text-neon-blue backdrop-blur">
            {product.subcategory.name}
          </span>
        )}
      </div>
      <div className="p-4">
        <h3 className="line-clamp-1 font-display text-sm font-semibold text-gray-100">
          {product.title}
        </h3>
        <div className="mt-2 flex items-center justify-between">
          <span className="text-lg font-bold text-neon-green">
            {formatPrice(product.priceCents)}
          </span>
          <button
            onClick={addToCart}
            disabled={adding || product.stock === 0}
            className="rounded-lg border border-neon-blue/50 p-2 text-neon-blue transition-all hover:bg-neon-blue/10 hover:shadow-neon-blue disabled:opacity-40"
            title="In den Warenkorb"
          >
            <ShoppingCart className="h-4 w-4" />
          </button>
        </div>
        {added && <p className="mt-1 text-xs text-neon-green">Hinzugefügt ✓</p>}
      </div>
    </Link>
  );
}
