"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { ShoppingCart, User, Menu, X, Zap, Wallet, LifeBuoy, LayoutDashboard, LogOut } from "lucide-react";
import { useAuth } from "./AuthProvider";
import { formatPrice } from "@/lib/format";

interface Subcategory {
  id: string;
  name: string;
  slug: string;
}
interface Category {
  id: string;
  name: string;
  slug: string;
  subcategories: Subcategory[];
}

export default function Navbar() {
  const { user, loading, logout } = useAuth();
  const [categories, setCategories] = useState<Category[]>([]);
  const [shopOpen, setShopOpen] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [userMenuOpen, setUserMenuOpen] = useState(false);
  const [cartCount, setCartCount] = useState(0);

  useEffect(() => {
    fetch("/api/categories")
      .then((r) => r.json())
      .then((d) => setCategories(d.categories ?? []))
      .catch(() => {});
  }, []);

  useEffect(() => {
    if (!user) {
      setCartCount(0);
      return;
    }
    fetch("/api/cart")
      .then((r) => r.json())
      .then((d) => setCartCount(d.items?.length ?? 0))
      .catch(() => {});
  }, [user]);

  return (
    <header className="sticky top-0 z-50 border-b border-white/10 bg-bg/80 backdrop-blur-xl">
      <nav className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3 md:px-8">
        <Link href="/" className="flex items-center gap-2 font-display text-xl font-black tracking-wider text-white">
          <Zap className="h-6 w-6 text-neon-blue drop-shadow-[0_0_6px_rgba(0,229,255,0.8)]" />
          <span className="bg-gradient-to-r from-neon-blue to-neon-purple bg-clip-text text-transparent">
            NEON<span className="text-white">SHOP</span>
          </span>
        </Link>

        <div className="hidden items-center gap-6 md:flex">
          <div
            className="relative"
            onMouseEnter={() => setShopOpen(true)}
            onMouseLeave={() => setShopOpen(false)}
          >
            <button className="nav-link flex items-center gap-1">Shop</button>
            {shopOpen && (
              <div className="absolute left-0 top-full grid w-[560px] grid-cols-2 gap-4 rounded-2xl border border-white/10 bg-bg-panel/95 p-6 shadow-glass backdrop-blur-xl">
                {categories.map((cat) => (
                  <div key={cat.id}>
                    <Link
                      href={`/shop?category=${cat.slug}`}
                      className="font-display text-sm font-bold uppercase tracking-wide text-neon-blue"
                    >
                      {cat.name}
                    </Link>
                    <ul className="mt-2 space-y-1.5">
                      {cat.subcategories.map((sub) => (
                        <li key={sub.id}>
                          <Link
                            href={`/shop?category=${cat.slug}&subcategory=${sub.slug}`}
                            className="text-sm text-gray-400 hover:text-white transition-colors"
                          >
                            {sub.name}
                          </Link>
                        </li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>
            )}
          </div>
          <Link href="/support" className="nav-link">Support</Link>
          {user?.role === "ADMIN" && (
            <Link href="/admin" className="nav-link text-neon-purple">Admin Panel</Link>
          )}
        </div>

        <div className="flex items-center gap-3">
          <Link href="/cart" className="relative rounded-xl p-2 text-gray-300 hover:text-neon-blue hover:shadow-neon-blue transition-all">
            <ShoppingCart className="h-5 w-5" />
            {cartCount > 0 && (
              <span className="absolute -right-1 -top-1 flex h-4.5 w-4.5 min-w-[18px] items-center justify-center rounded-full bg-neon-pink px-1 text-[10px] font-bold text-white">
                {cartCount}
              </span>
            )}
          </Link>

          {!loading && !user && (
            <Link href="/login" className="neon-btn hidden sm:inline-flex">
              Login
            </Link>
          )}

          {!loading && user && (
            <div className="relative">
              <button
                onClick={() => setUserMenuOpen((v) => !v)}
                className="flex items-center gap-2 rounded-xl border border-white/10 bg-bg-panel px-3 py-2 text-sm text-gray-200 hover:border-neon-blue/50 transition-colors"
              >
                <User className="h-4 w-4 text-neon-blue" />
                <span className="hidden sm:inline">{user.username}</span>
                <span className="hidden md:inline text-xs text-neon-green">
                  {formatPrice(user.balanceCents)}
                </span>
              </button>
              {userMenuOpen && (
                <div className="absolute right-0 top-full mt-2 w-56 rounded-xl border border-white/10 bg-bg-panel/95 p-2 shadow-glass backdrop-blur-xl">
                  <Link href="/dashboard" onClick={() => setUserMenuOpen(false)} className="flex items-center gap-2 rounded-lg px-3 py-2 text-sm text-gray-300 hover:bg-white/5">
                    <LayoutDashboard className="h-4 w-4" /> Dashboard
                  </Link>
                  <Link href="/dashboard/wallet" onClick={() => setUserMenuOpen(false)} className="flex items-center gap-2 rounded-lg px-3 py-2 text-sm text-gray-300 hover:bg-white/5">
                    <Wallet className="h-4 w-4" /> Wallet
                  </Link>
                  <Link href="/dashboard/tickets" onClick={() => setUserMenuOpen(false)} className="flex items-center gap-2 rounded-lg px-3 py-2 text-sm text-gray-300 hover:bg-white/5">
                    <LifeBuoy className="h-4 w-4" /> Support-Tickets
                  </Link>
                  <button
                    onClick={() => logout()}
                    className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-left text-sm text-red-400 hover:bg-red-500/10"
                  >
                    <LogOut className="h-4 w-4" /> Logout
                  </button>
                </div>
              )}
            </div>
          )}

          <button className="p-2 md:hidden" onClick={() => setMobileOpen((v) => !v)}>
            {mobileOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </button>
        </div>
      </nav>

      {mobileOpen && (
        <div className="border-t border-white/10 bg-bg-panel/95 px-4 py-4 md:hidden">
          <Link href="/shop" className="block py-2 text-gray-300">Shop</Link>
          <Link href="/support" className="block py-2 text-gray-300">Support</Link>
          {!user && <Link href="/login" className="block py-2 text-neon-blue">Login</Link>}
          {user?.role === "ADMIN" && (
            <Link href="/admin" className="block py-2 text-neon-purple">Admin Panel</Link>
          )}
        </div>
      )}
    </header>
  );
}
