import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { NextRequest } from "next/server";
import { prisma } from "./prisma";

const JWT_SECRET = process.env.JWT_SECRET as string;
const COOKIE_NAME = "session_token";
const TOKEN_TTL = "7d";

if (!JWT_SECRET && process.env.NODE_ENV === "production") {
  // Fail fast in Produktion, falls kein Secret gesetzt wurde
  throw new Error("JWT_SECRET ist nicht gesetzt. Bitte in .env definieren.");
}

export interface SessionPayload {
  userId: string;
  username: string;
  role: "USER" | "ADMIN";
}

export async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, 12);
}

export async function verifyPassword(
  password: string,
  hash: string
): Promise<boolean> {
  return bcrypt.compare(password, hash);
}

export function signSession(payload: SessionPayload): string {
  return jwt.sign(payload, JWT_SECRET, { expiresIn: TOKEN_TTL });
}

export function verifySession(token: string): SessionPayload | null {
  try {
    return jwt.verify(token, JWT_SECRET) as SessionPayload;
  } catch {
    return null;
  }
}

export const SESSION_COOKIE_NAME = COOKIE_NAME;

/**
 * Liest den eingeloggten User aus dem Request (Cookie-basiert).
 * Gibt null zurück, wenn kein gültiges Token vorhanden ist.
 */
export async function getCurrentUser(req: NextRequest) {
  const token = req.cookies.get(COOKIE_NAME)?.value;
  if (!token) return null;

  const payload = verifySession(token);
  if (!payload) return null;

  const user = await prisma.user.findUnique({ where: { id: payload.userId } });
  if (!user || user.isBanned) return null;

  return user;
}

/** Prüft, ob der eingeloggte User Admin ist. Wirft sonst einen Fehler. */
export async function requireAdmin(req: NextRequest) {
  const user = await getCurrentUser(req);
  if (!user || user.role !== "ADMIN") {
    throw new Error("UNAUTHORIZED");
  }
  return user;
}
