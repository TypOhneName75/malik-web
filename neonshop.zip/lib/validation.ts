import { z } from "zod";

export const registerSchema = z.object({
  username: z
    .string()
    .min(3, "Username muss mindestens 3 Zeichen lang sein")
    .max(24, "Username darf maximal 24 Zeichen lang sein")
    .regex(/^[a-zA-Z0-9_]+$/, "Nur Buchstaben, Zahlen und _ erlaubt"),
  password: z
    .string()
    .min(8, "Passwort muss mindestens 8 Zeichen lang sein")
    .max(128, "Passwort zu lang"),
});

export const loginSchema = z.object({
  username: z.string().min(1, "Username erforderlich"),
  password: z.string().min(1, "Passwort erforderlich"),
});

export const changePasswordSchema = z.object({
  currentPassword: z.string().min(1),
  newPassword: z.string().min(8).max(128),
});

export const productSchema = z.object({
  title: z.string().min(1).max(200),
  description: z.string().min(1).max(5000),
  priceCents: z.number().int().nonnegative(),
  stock: z.number().int().nonnegative(),
  images: z.array(z.string().url()).default([]),
  categoryId: z.string().min(1),
  subcategoryId: z.string().min(1),
  isActive: z.boolean().optional(),
});

export const cartAddSchema = z.object({
  productId: z.string().min(1),
  quantity: z.number().int().positive().max(99).default(1),
});

export const ticketCreateSchema = z.object({
  subject: z.string().min(3).max(200),
  category: z.string().min(1).max(100),
  message: z.string().min(1).max(4000),
});

export const ticketReplySchema = z.object({
  message: z.string().min(1).max(4000),
});
